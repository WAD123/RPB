<?php
		
			$name=$_POST['name'];
			$phn=$_POST['phone'];
			$email=$_POST['email'];
			$dof=$_POST['dateoffunction'];
			$gather=$_POST['expectedgathering'];
			$unit=$_POST['chooseunit'];
			$msg=$_POST['textarea-34'];

			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Feedback";
			$txt = "Customer Name: ".$name."."."\r\n"."Customer Phone Number: ".$phn."."."\r\n"."Date of function: ".$dof."."."\r\n"."Expected Gathering: ".$gather."."."\r\n"."Unit: ".$unit."."."\r\n"."Customer Message: ".$msg;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);
				
			$link=mysqli_connect("localhost","root","wad@root123","royal_pepper");

			$sql = "INSERT INTO contactform_big(Cust_Name,Email,Phone,Date_Of_Function,Expect_Gather,Unit,Message) VALUES ('".$name."','".$email."','".$phn."','".$dof."','".$gather."','".$unit."','".$msg."')";

			mysqli_query($link, $sql);

			mysqli_close($link);
		
?>