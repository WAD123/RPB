
<?php
$name=$_REQUEST['txtname'];
$phn=$_REQUEST['txtphn'];
$email=$_REQUEST['txtmail'];
$msg=$_REQUEST['txtmessage'];
// $to = "royalpepperbanquets@gmail.com";
// $subject = "RPB Feedback";
// $txt = "Customer Name: ".$name."."."\r\n"."Customer Phone Number: ".$phn."."."\r\n"."Customer Message: ".$msg;
// $headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbNquets.com";

// mail($to,$subject,$txt,$headers);

	$link=mysqli_connect("localhost","root","wad@root123","royal_pepper");

	if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "INSERT INTO contactform_small VALUES ('".$name."','".$phn."','".$email."','".$msg."')";

if (mysqli_query($link, $sql)) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($link);
}

mysqli_close($link);


?>