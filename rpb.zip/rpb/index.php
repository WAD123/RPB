<?php
		if(isset($_POST['submitbig'])){
			$name=$_REQUEST['txtname'];
			$phn=$_REQUEST['txtphn'];
			$email=$_REQUEST['txtmail'];
			$dof=$_REQUEST['txtdof'];
			$gather=$_REQUEST['expectgather'];
			$unit=$_REQUEST['selectunit'];
			$msg=$_REQUEST['txtmessage'];

			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Feedback";
			$txt = "Customer Name: ".$name."."."\r\n"."Customer Phone Number: ".$phn."."."\r\n"."Date of function: ".$dof."."."\r\n"."Expected Gathering: ".$gather."."."\r\n"."Unit: ".$unit."."."\r\n"."Customer Message: ".$msg;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);
				
			$link=mysqli_connect("localhost","root","wad@root123","royal_pepper");

			if (!$link) {
				 ?>
			   <script>alert("Connection Failed. There is some problem.");</script>
			    <?php
			    
			}

			$sql = "INSERT INTO contactform_big(Cust_Name,Email,Phone,Date_Of_Function,Expect_Gather,Unit,Message) VALUES ('".$name."','".$email."','".$phn."','".$dof."','".$gather."','".$unit."','".$msg."')";

			if (mysqli_query($link, $sql)) {
					  ?>
	    			    <script>alert("Your details have been submitted. We will get back to you soon.");</script>
	   				 <?php
	   				 

			} else {
			    ?>
			   <script>alert("There is some problem.");</script>
			    <?php
			   
			}

			mysqli_close($link);
		}
		
		if(isset($_POST['submitsmall'])){
			$name=$_REQUEST['txtname'];
			$phn=$_REQUEST['txtphn'];
			$email=$_REQUEST['txtmail'];
			$msg=$_REQUEST['txtmessage'];
			
			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Feedback";
			$txt = "Customer Name: ".$name."."."\r\n"."Customer Phone Number: ".$phn."."."\r\n"."Customer Message: ".$msg;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);

				$link1=mysqli_connect("localhost","root","wad@root123","royal_pepper");

				if (!$link1) {
				 ?>
			   <script>alert("Connection Failed. There is some problem.");</script>
			    <?php
			    
			}

			$sql = "INSERT INTO contactform_small(Cust_Name,Phone,Email,Message) VALUES ('".$name."','".$phn."','".$email."','".$msg."')";

			if (mysqli_query($link1, $sql)) {
				  ?>
	    			    <script>alert("Your details have been submitted. We will get back to you soon.");</script>
	   			 <?php
	   			
				
			} else {
				 ?>
			   <script>alert("There is some problem.");</script>
			    <?php
			   
			}

			mysqli_close($link1);

		}

		if(isset($_POST['submitfeedback'])){
			$name=$_REQUEST['name'];
			$email=$_REQUEST['email'];
			$msg=$_REQUEST['message'];
			
			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Feedback";
			$txt = "Customer Name: ".$name."."."\r\n"."Customer Email: ".$email."."."\r\n"."Customer Feedback: ".$msg;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);

				$link2=mysqli_connect("localhost","root","wad@root123","royal_pepper");

				if (!$link2) {
				 ?>
			   <script>alert("Connection Failed. There is some problem.");</script>
			    <?php
			    
			}

			$sql = "INSERT INTO feedback(name,email,feedback) VALUES ('".$name."','".$email."','".$msg."')";

			if (mysqli_query($link2, $sql)) {
				  ?>
	    			    <script>alert("Thank You for your Valuable feedback.");</script>
	   			 <?php
	   			
				
			} else {
				 ?>
			   <script>alert("There is some problem.");</script>
			    <?php
			   
			}

			mysqli_close($link2);

		}

		if(isset($_POST['submitcareer'])){
			$name=$_REQUEST['careername'];
			$email=$_REQUEST['careeremail'];
			$phone=$_REQUEST['careernumber'];
			
			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Career";
			$txt = "Applicant Name: ".$name."."."\r\n"."Applicant Email: ".$email."."."\r\n"."Applicant Phone Number: ".$phone;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);

				$link2=mysqli_connect("localhost","root","wad@root123","royal_pepper");

				if (!$link2) {
				 ?>
			   <script>alert("Connection Failed. There is some problem.");</script>
			    <?php
			    
			}

			$sql = "INSERT INTO career(name,email,phone) VALUES ('".$name."','".$email."','".$phone."')";

			if (mysqli_query($link2, $sql)) {
				  ?>
	    			    <script>alert("Your details have been submitted. We will get back to you soon.");</script>
	   			 <?php
	   			
				
			} else {
				 ?>
			   <script>alert("There is some problem.");</script>
			    <?php
			   
			}

			mysqli_close($link2);

		}
	?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta http-equiv="content-type" content="text/html">
	<title> Best Wedding Marriage Halls Wazirpur Banquet In Rohin Peeragarhi Delhi India | Royal Pepper Banquets</title>
	<meta name="description" content=" Royal Pepper Banquets is a renowned Marriage and Wedding Hall in North Delhi India, providing excellent and luxurious wedding halls, exceptional catering facilities at affordable rates.">
	<meta name="keywords" content="banquets hall in north delhi, wedding halls in peeragarhi, banquet halls in peeragarhi, best marriage halls in peeragarhi, banquet halls in wazirpur, best banquet in wazirpur, marriage halls in wazirpur, wedding halls in wazirpur, best banquet halls in rohini, marriage halls in rohini, wedding halls in rohini india">
	
	<!-- MY CSS -->
	<link rel="stylesheet" href="css/mystyle.css" type="text/css" />
	
	<!-- Stylesheets ============================================ -->
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="css/style.css" type="text/css" />
	<link rel="stylesheet" href="css/main.css" type="text/css">
	<!-- One Page Module Specific Stylesheet -->
	<link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
	<link rel="stylesheet" href="css/onepage.css" type="text/css" />
	<link rel="stylesheet" href="css/dark.css" type="text/css" />
	<link rel="stylesheet" href="css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="css/et-line.css" type="text/css" />
	<link rel="stylesheet" href="css/animate.css" type="text/css" />
	<link rel="stylesheet" href="css/magnific-popup.css" type="text/css" />
	<link rel="stylesheet" href="css/fonts.css" type="text/css" />
	<link rel="stylesheet" href="css/responsive.css" type="text/css" />
	 <link rel="canonical" href="http://www.royalpepperbanquets.com/" />	
	
	<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
	<![endif]-->
	<!-- SLIDER REVOLUTION 5.x CSS SETTINGS -->
	<link rel="stylesheet" type="text/css" href="include/rs-plugin/css/settings.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="include/rs-plugin/css/layers.css">
	<link rel="stylesheet" type="text/css" href="include/rs-plugin/css/navigation.css">
	<!-- ADD-ONS CSS FILES -->
	<link rel="stylesheet" href="include/rs-plugin/fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" type="text/css">
	<link rel="stylesheet" type="text/css" href="include/rs-plugin/css/addons/revolution.addon.polyfold.css">

	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106006908-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-106006908-1');
</script>

<!-- Google Code for Remarketing Tag -->
<!--
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
-->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 822487020;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/822487020/?guid=ON&amp;script=0"/>
</div>
</noscript>
<style>
	   .flex-container {
      position: absolute;
      height: 85vh;
      width: 100%;
      display: -webkit-flex;
      /* Safari */
      display: flex;
      overflow: hidden;
    }

    .flex-about p{
        height: 100%;
    }

@media screen and (max-width: 768px) {

.flex-container { flex-direction: column; }
}

.flex-title {
  color: #f1f1f1;
  position: relative;
  font-size: 2.7em;
  margin: auto;
  text-align: center;
  transform: rotate(90deg);
  top: 15%;
  -webkit-transition: all 500ms ease;
  -moz-transition: all 500ms ease;
  -ms-transition: all 500ms ease;
  -o-transition: all 500ms ease;
  transition: all 500ms ease;
}

@media screen and (max-width: 768px) {

.flex-title { transform: rotate(0deg) !important; }
}

.flex-about {
  opacity: 0;
  /*color: #f1f1f1;*/
  height: 60%;
  position: relative;
  width: 80%;
  /*font-size: 2vw;*/
  /*padding: 5%;*/
  top: 20%;
  /*border: 2px solid #f1f1f1;*/
  /*border-radius: 10px;*/
  line-height: 1.3;
  margin: auto;
  text-align: left;
  transform: rotate(0deg);
  -webkit-transition: all 500ms ease;
  -moz-transition: all 500ms ease;
  -ms-transition: all 500ms ease;
  -o-transition: all 500ms ease;
  transition: all 500ms ease;
}

@media screen and (max-width: 768px) {

.flex-about {
  padding: 0%;
  border: 0px solid #f1f1f1;
}
}

.flex-slide {
  -webkit-flex: 1;
  /* Safari 6.1+ */
  -ms-flex: 1;
  /* IE 10 */
  flex: 1;
  cursor: pointer;
  -webkit-transition: all 500ms ease;
  -moz-transition: all 500ms ease;
  -ms-transition: all 500ms ease;
  -o-transition: all 500ms ease;
  transition: all 500ms ease;
}

@media screen and (max-width: 768px) {

.flex-slide {
  overflow: auto;
  overflow-x: hidden;
}
}

@media screen and (max-width: 768px) {

.flex-slide p { font-size: 2em; }
}

@media screen and (max-width: 768px) {

.flex-slide ul li { font-size: 2em; }
}

.flex-slide:hover {
  -webkit-flex-grow: 3;
  flex-grow: 3;
}

.home {
  background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/769286/lake-macquarie-71208_1920.jpg);
  background-size: cover;
  background-position: center center;
  background-attachment: fixed;
}
.work {
  background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/769286/lake-macquarie-71208_1920.jpg);
  background-size: cover;
  background-position: center center;
  background-attachment: fixed;
}
.contact {
  background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/769286/beach-2089959_1280.jpg);
  background-size: cover;
  background-position: center center;
  background-attachment: fixed;
}

@media screen and (min-width: 768px) {

.home {
  -moz-animation: aboutFlexSlide;
  -moz-animation-duration: 3s;
  -moz-animation-iteration-count: 1;
  -moz-animation-delay: 0s;
  -webkit-animation: aboutFlexSlide;
  -webkit-animation-duration: 3s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-delay: 0s;
  animation: aboutFlexSlide;
  animation-duration: 3s;
  animation-iteration-count: 1;
  animation-delay: 0s;
}
}

@keyframes 
aboutFlexSlide {  0% {
 -webkit-flex-grow: 1;
 flex-grow: 1;
}
 50% {
 -webkit-flex-grow: 3;
 flex-grow: 3;
}
 100% {
 -webkit-flex-grow: 1;
 flex-grow: 1;
}
}

@media screen and (min-width: 768px) {

.flex-title-home {
  transform: rotate(90deg);
  top: 15%;
  -moz-animation: homeFlextitle;
  -moz-animation-duration: 3s;
  -moz-animation-iteration-count: 1;
  -moz-animation-delay: 0s;
  -webkit-animation: homeFlextitle;
  -webkit-animation-duration: 3s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-delay: 0s;
  animation: homeFlextitle;
  animation-duration: 3s;
  animation-iteration-count: 1;
  animation-delay: 0s;
}
}

@keyframes 
homeFlextitle {  0% {
 transform: rotate(90deg);
 top: 15%;
}
 50% {
 transform: rotate(0deg);
 top: 15%;
}
 100% {
 transform: rotate(90deg);
 top: 15%;
}
}

.flex-about-home { opacity: 0; }

@media screen and (min-width: 768px) {

.flex-about-home {
  -moz-animation: flexAboutHome;
  -moz-animation-duration: 3s;
  -moz-animation-iteration-count: 1;
  -moz-animation-delay: 0s;
  -webkit-animation: flexAboutHome;
  -webkit-animation-duration: 3s;
  -webkit-animation-iteration-count: 1;
  -webkit-animation-delay: 0s;
  animation: flexAboutHome;
  animation-duration: 3s;
  animation-iteration-count: 1;
  animation-delay: 0s;
}
}

@keyframes 
flexAboutHome {  0% {
 opacity: 0;
}
 50% {
 opacity: 1;
}
 100% {
 opacity: 0;
}
}

.about {
  background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(https://s3-us-west-2.amazonaws.com/s.cdpn.io/769286/beach-2089959_1280.jpg);
  background-size: cover;
  background-position: center center;
  background-attachment: fixed;
}
</style>

		
	<link id="swcolors-Css" rel="stylesheet" href="css/colors.css" type="text/css">
	<link rel="icon" href="include/rs-plugin/demos/assets/images/rpb.png">
</head>
<body class="stretched" style="overflow-x:hidden;" data-loader="4" oncontextmenu="return false;">
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PPJWK7G"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">
		<!-- Header
		============================================= -->
		<header id="header" class="full-header" data-sticky-class="not-dark">
			<div id="header-wrap">
				<div class="container clearfix">
					<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>
					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="http://www.royalpepperbanquets.com" class="standard-logo"><img src="images/logo.png" alt="Royal Pepper Banquets"></a>
						<a href="http://www.royalpepperbanquets.com" class="retina-logo" ><img src="images/logo.png" alt="Royal Pepper Banquets"></a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu">

						<ul>
							<li class="current"><a href="http://www.royalpepperbanquets.com"><div>Home</div></a>
								
							</li>
							<li><a href="http://www.royalpepperbanquets.com/#units"><div>Our Units</div></a>
								<ul>
									<li class="sub-menu"><a href="/peeragarhi/" data-toggle="tooltip" data-placement="right" title=""><div>Peeragarhi</div></a>
										
									</li>
										
							
									<li class="sub-menu"><a href="/wazirpur/"><div>Wazirpur </div></a>
										
									</li>
									<li class="sub-menu"><a href="/rohini/"><div>Rohini</div></a>
										<ul>
											<li class="sub-menu"><a href="/rohini/"><div>Rohini Sec-3</div></a></li>
											<li class="sub-menu"><a href="/rohini-sec-10/" data-toggle="tooltip" data-placement="right"><div>Rohini Sec-10</div></a></li>
										</ul>
									</li>																		
								</ul>
							</li>
							<li><a href="/gallery/"><div>Gallery</div></a>							
							</li>
							<li><a href="/about-us/"><div>About Us</div></a>							
							</li>
							<li><a href="/banquets-update/"><div>Blog</div></a>							
							</li>
							<li><a href="/contact-us/"><div>Contact Us</div></a>							
							</li>					
						</ul>					
					</nav><!-- #primary-menu end -->
				</div>
			</div>
		</header><!-- #header end -->
		<!-- Slider 1-->
		<section id="banner" class="slider" class="revslider-wrap full-screen clearfix">

		<div id="demo-slider" class="carousel slide" data-ride="carousel" data-pause="false">
							<!-- Indicators -->
						  <!-- 	<ol class="carousel-indicators">
							    <li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
							    <li data-target="#carousel-slider" data-slide-to="1"></li>
							    <li data-target="#carousel-slider" data-slide-to="2"></li>
							    
						  	</ol> -->

							<div class="carousel-inner">
								<div class="item active">
								
								<img id="banner-img1" src="include/rs-plugin/demos/assets/images/wazirpur.jpg" alt="top wedding banquet in wazirpur" width="100%">
									
							   </div>
							   <div class="item">
							  	 <img id="banner-img2" src="include/rs-plugin/demos/assets/images/peeragarhi.jpg" alt="luxury wedding banquets in peeragarhi" width="100%">
									
							   </div> 
							   <div class="item">
							   	<img id="banner-img3" src="include/rs-plugin/demos/assets/images/rohini.jpg" alt="luxurious banquets hall in rohini" width="100%">
									
							   </div>
							   
							   
							</div>
							
							
							<a class="left carousel-control hidden" href="#demo-slider" data-slide="prev" style="margin:0px 0 10em;">
								<i class="icon-angle-left" style="color:#dfa700; left:0px;"></i> 
							</a>
							
							<a class="right carousel-control hidden" href="#demo-slider" data-slide="next" style="margin: 0px 0 10em;">
								<i class="icon-angle-right" style="color:#dfa700; right:0px;"></i> 
							</a>
						</div> <!--/#carousel-slider-->
			<!-- END REVOLUTION SLIDER -->
		</section>			

<!--******************************************************************************************************* -->	
		<!-- Slider 2
		============================================= -->
		<div id="units-back-image" style="background:linear-gradient(rgba(0,0,0,0.9),rgba(0,0,0,0.9)),url(include/rs-plugin/demos/assets/images/units-back.jpg);background-repeat: no-repeat;background-size: 100% 100%; background-attachment: fixed;">

					<!-- units new section starts -->
					<!-- <section id="units" class="full-screen force-full-screen">
						<div>
								<h2 class="my-h1-tags nomargin" style="padding: 2%;">Our Units</h2>
							</div>
						<div class="flex-container">
						  
						  <div class="flex-slide home">
						    <div class="flex-title flex-title-home">Wazirpur</div>
						    <div class="flex-about flex-about-home"><p><iframe src="https://www.google.com/maps/embed?pb=!1m0!4v1510732568457!6m8!1m7!1sCAoSLEFGMVFpcFBONVE2UUdFM1BFME5QTFVJckR5UEl4d0RWS0JTY0Q1MGJMNVFu!2m2!1d28.704504983982!2d77.172367640107!3f283.8079587914339!4f-2.809394576320827!5f0.7820865974627469" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe></p></div>
						  </div>
						  <div class="flex-slide about" style="margin: 0px;">
						    <div class="flex-title">Rohini</div>
						    <div class="flex-about">
						    	<p>
									<video width="100%" preload="none" loop muted autoplay="autoplay" data-animate="bounceInUp" data-delay="500">
										<source src='images/videos/rpb-r.webm' type='video/webm' />
										
									</video>
									
								</p>
							</div>
						  </div>
						  <div class="flex-slide work">
						    <div class="flex-title">Peeragarhi</div>
						    <div class="flex-about"><p><iframe src="https://www.google.com/maps/embed?pb=!1m0!4v1510732568457!6m8!1m7!1sCAoSLEFGMVFpcFBONVE2UUdFM1BFME5QTFVJckR5UEl4d0RWS0JTY0Q1MGJMNVFu!2m2!1d28.704504983982!2d77.172367640107!3f283.8079587914339!4f-2.809394576320827!5f0.7820865974627469" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe></p></div>
						  </div>
						  <div class="flex-slide contact">
						    <div class="flex-title">Maiden</div>
						    <div class="flex-about"><p><iframe src="https://www.google.com/maps/embed?pb=!1m0!4v1510732568457!6m8!1m7!1sCAoSLEFGMVFpcFBONVE2UUdFM1BFME5QTFVJckR5UEl4d0RWS0JTY0Q1MGJMNVFu!2m2!1d28.704504983982!2d77.172367640107!3f283.8079587914339!4f-2.809394576320827!5f0.7820865974627469" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe></p></div>
						  </div>
						</div>
					</section> -->
					<!-- units new section ends -->

					<section id="units" class="slider" class="slider-parallax full-screen force-full-screen">
				<div>
					<h2 class="my-h1-tags">Our Units</h2>
				</div>
				<div class="slider-parallax-inner lazy">
				
					<div class="full-screen force-full-screen section nopadding nomargin noborder ohidden" style="background-color: transparent;">
						<a href="/wazirpur/">
							<div id="wazir-a" class="col-xs-12 nopadding half-screen videoplay-on-hover">
								<a href="#" class="view-360" data-toggle="modal" data-target="#myModalwazirpur"><img src="images/360.png" width="15%"></a>
								<div id="wazir-h2" class="vertical-middle ignore-header center">
									
									<h2 class="nobottommargin ls1 topmargin-xxs">Wazirpur</h2>
									<h5 style="" class="video-text-para topmargin-md">Located in the supreme locality of Wazirpur Industrial Area, with revolutionary interiors, alluringly crafted to hold massive gatherings with ease, Royal Pepper Banquet halls in Delhi will lure you to appoint us, yet again!</h5>
								</div>
								<div class="video-wrap">
									<video id="slide-video1" preload="none" loop muted autoplay="autoplay" data-animate="bounceInLeft" data-delay="300">
										<source src='images/videos/rpb-w.webm' type='video/webm' />
										<!-- <source class="hide-video" src='images/videos/rpb-w.mp4' type='video/mp4' /> -->
									</video>
									<div class="video-overlay" style="background-color: rgba(0,0,0,0.5);"></div>
								</div>
							</div>
						</a>
						<a href="/rohini/">
							<div id="rohini-a" class="col-xs-12 nopadding half-screen videoplay-on-hover">
								<div id="rohini-h2" class="vertical-middle ignore-header center">
									<h2 class="nobottommargin ls1 topmargin-xxs">Rohini</h2>
									<h5 style="" class="video-text-para topmargin-md">Specially streamlined to serve the best for our customers, our Banquet halls in North Delhi have proved to be a remarkable host for all your occasions, at the best prices with everything exquisite, from furniture to cuisine.</h5>
								</div>
								<div class="video-wrap">
									<video id="slide-video2" preload="none" loop muted autoplay="autoplay" data-animate="bounceInUp" data-delay="500">
										<source src='images/videos/rpb-r.webm' type='video/webm' />
										<!-- <source class="hide-video" src='images/videos/rpb-r.mp4' type='video/mp4' /> -->
									</video>
									<div class="video-overlay" style="background-color: rgba(0,0,0,0.5);"></div>
								</div>
							</div>
						</a>
						<a href="/peeragarhi/">
							<div id="peera-a" class="col-xs-12 nopadding half-screen videoplay-on-hover">
								<a href="#" class="view-360" data-toggle="modal" data-target="#myModalpeeragarhi"><img src="images/360.png" width="15%"></a>
								<div id="peera-h2" class="vertical-middle ignore-header center">
									
									<h2 class="nobottommargin ls1 topmargin-xxs">Peeragarhi</h2>
									<h5 style="" class="video-text-para topmargin-md">From delicate ambience to amiable staff, banquet halls in Delhi brings you a new feeling of royalty in your celebrations. Our special wedding venues and party halls invite the best experience for you for every special moment.</h5>
								</div>
								<div class="video-wrap">
									<video id="slide-video3" preload="none" loop muted autoplay="autoplay" data-animate="bounceInRight" data-delay="700">
										<source src='images/videos/rpb-p.webm' type='video/webm' title="Video of Place of Dreams Banquets Peeragarhi by Royal Pepper Banquets" />
										<!-- <source class="hide-video" src='images/videos/rpb-p.mp4' type='video/mp4' title="Video of Place of Dreams Banquets Peeragarhi by Royal Pepper Banquets" /> -->
									</video>
									<div class="video-overlay" style="background-color: rgba(0,0,0,0.5);"></div>
								</div>
							</div>
						</a>					
						
					</div>
				</div>
				
			</section>		


		
			
			<div id="myModalwazirpur" class="modal">
			
			  
			  <div class="modal-content">
			    <div class="modal-header">
			      <span class="close" data-dismiss="modal">&times;</span>
			      
			    </div>
			    <div class="modal-body">
					<iframe src="https://www.google.com/maps/embed?pb=!1m0!4v1510732568457!6m8!1m7!1sCAoSLEFGMVFpcFBONVE2UUdFM1BFME5QTFVJckR5UEl4d0RWS0JTY0Q1MGJMNVFu!2m2!1d28.704504983982!2d77.172367640107!3f283.8079587914339!4f-2.809394576320827!5f0.7820865974627469" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
			    </div>
			   
			  </div>
			
			</div>

			<div id="myModalpeeragarhi" class="modal">
			
			  
			  <div class="modal-content">
			    <div class="modal-header">
			      <span class="close" data-dismiss="modal">&times;</span>
			      
			    </div>
			    <div class="modal-body">
				<iframe src="https://www.google.com/maps/embed?pb=!1m0!4v1510737260434!6m8!1m7!1sCAoSLEFGMVFpcE5nM1NjamlGaXRtNnphVW9LNmgweGpMREowU0xoRFVYN250c05r!2m2!1d28.68011308867027!2d77.09367120699335!3f103!4f0!5f0.7820865974627469" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>
			    </div>
			   
			  </div>
			
			</div>

			
			<!-- Slider 3
			============================================= -->

			<section id="item-3" class="slider" class="revslider-wrap clearfix" style="height:100%;">
				<div data-animate="rotateInDownLeft" data-delay="200">
					<h2 class="my-h1-tags">Our Gallery</h2>
				</div>
				<div id="rev_slider_108_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container lazy" data-alias="food-carousel80" style="margin:0px auto;background-color:#eef0f1;padding:0px;margin-top:0px;margin-bottom:0px;">
					<!-- START REVOLUTION SLIDER 5.0.7 fullwidth mode -->
					<div id="rev_slider_108_1" class="rev_slider fullwidthabanner" style="display:none;" data-version="5.0.7"  data-animate="bounceInLeft" data-delay="600">
						<ul>	<!-- SLIDE  -->
							<li data-index="rs-325" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/1-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/1.jpg"  alt=" wedding decor entrance gate "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>
							<!-- SLIDE  -->
							<li data-index="rs-326" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/2-1.jpg"  data-rotate="0"  data-saveperformance="off" data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/2.jpg"  alt=" banquet halls for weddings and parties "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>
							<!-- SLIDE  -->
							<li data-index="rs-327" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/3-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/3.jpg"  alt=" banquet halls decoration for wedding and parties "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>
							<!-- SLIDE  -->
							<li data-index="rs-328" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/4-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/4.jpg"  alt=" wedding banquet hall decoration ideas "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>
							<!-- SLIDE  -->
							<li data-index="rs-329" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/5-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/5.jpg"  alt=" wedding stage decoration with flowers "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>
							<!-- SLIDE  -->
							<li data-index="rs-330" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/6-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/6.jpg"  alt=" wedding seating arrangement decorations "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>
							<!-- SLIDE  -->
							<li data-index="rs-331" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/7-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/7.jpg"  alt=" marriage hall decoration designs "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>

							<li data-index="rs-332" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/8-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/8.jpg"  alt=" catering buffet table decorations "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>

							<li data-index="rs-333" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/9-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/9.jpg"  alt=" guest waiting room and lobby "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>

							<li data-index="rs-334" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/10-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/10.jpg"  alt=" wedding drinks stalls "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>

							<li data-index="rs-335" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/11-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/11.jpg"  alt=" wedding mocktails stalls "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>

							<li data-index="rs-336" data-transition="opacity:0.6" data-slotamount="12"  data-easein="default" data-easeout="default" data-masterspeed="300"  data-thumb="images/home-carousel/12-1.jpg"  data-rotate="0"  data-saveperformance="off"  data-description="">
								<!-- MAIN IMAGE -->
								<img src="images/home-carousel/12.jpg"  alt=" luxury decorated dining table for wedding "  data-bgposition="center center" data-bgfit="contain" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
								
							</li>
						</ul>
						<div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
					</div><!-- END REVOLUTION SLIDER -->
				</div>

			</section><!-- #content end -->
		</div>
		<!-- Element 4 -->
		
		<section id="content" style="margin-bottom: 0px;">

			

				<div class="forcefullwidth_wrapper_tp_banner lazy" id="rev_slider_5_1_forcefullwidth" style="position:relative;width:100%;height:auto;margin-top:0px;margin-bottom:0px"><div id="first-service-div" class="rev_slider_wrapper" data-alias="app-showcase" data-source="gallery" >

					<!-- START REVOLUTION SLIDER 5.3.1.6 fullwidth mode -->
					<div id="rev_slider_5_1" class="rev_slider fullwidthabanner revslider-initialised tp-simpleresponsive" style="max-height: 100%; margin-top: 0px; margin-bottom: 0px; height: 100%;" data-version="5.4.1" data-slideactive="rs-9">

						<ul class="tp-revslider-mainul" id="service-ul">	<!-- SLIDE  -->
							<li id="service-li" data-index="rs-9" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-rotate="0" data-saveperformance="off" data-title="Template"  class="tp-revslider-slidesli active-revslide" >

								<!-- MAIN IMAGE -->
								<div class="slotholder" style="position: absolute; top: 0px; left: 0px; z-index: 0; width: 100%; height: 100%; visibility: inherit; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"><div id="service-cover" class="tp-bgimg defaultimg " style="background:linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)),url(include/rs-plugin/demos/assets/images/services-background.jpg); height: 100%;width: 100%; opacity: 1; visibility: inherit; z-index: 20; background-size: 100% 100%;" src="include/rs-plugin/demos/assets/images/transparent.png"></div></div>
								<div class="heading" data-animate="rollIn" data-delay="200"><h2 > Our Services </h2></div>
								<!-- LAYERS -->

									<!-- LAYER NR. 1 -->
								<div  id="wedding" class="tp-parallax-wrap  tp-selecttoggle tp-parallax-container"><div id="wedding-1" class="tp-loop-wrap"><div id="wedding-2" class="tp-mask-wrap"><div class="tp-caption  rev_group rs-parallaxlevel-10 tp-withaction wedding-3" id="slide-9-layer-8" data-x="['left','left','center','center']" data-hoffset="['100','50','-240','-115']" data-y="['top','top','top','top']" data-voffset="['160','130','60','50']" data-width="['270','270','220','220']" data-height="170" data-whitespace="nowrap" data-type="group" data-actions="[{&quot;event&quot;:&quot;mouseenter&quot;,&quot;action&quot;:&quot;startlayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-55&quot;,&quot;delay&quot;:&quot;&quot;},{&quot;event&quot;:&quot;mouseleave&quot;,&quot;action&quot;:&quot;stoplayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-55&quot;,&quot;delay&quot;:&quot;&quot;}]" data-responsive_offset="on" data-wrapper_class="tp-selecttoggle" data-frames="[{&quot;delay&quot;:600,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">

								<!-- LAYER NR. 3 -->
								<div class="tp-parallax-wrap" style="position: relative; display: block; visibility: visible; top: 60px; z-index: 41;text-align:center;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 95%; line-height: 22px; font-weight: 500; color: #dfa700;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">Wedding &amp; Pre-Wedding Venues</div></div></div></div>

								<!-- LAYER NR. 4 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top:30%; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: hidden; transform: matrix(1, 0, 0, 1, 0, 0);"><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme rev_layer_in_group" id="slide-9-layer-5" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['45','45','45','45']" data-width="['270','270','210','210']" data-height="3" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:750,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[100%];opacity:1;&quot;,&quot;mask&quot;:&quot;x:0px;y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 8; background-color: #fff; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-family:century gothic; font-weight: 400; font-size: 20px; white-space: nowrap; min-height: 3px; min-width: 270px; max-height: 3px; max-width: 270px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> </div></div></div></div>

								<!-- LAYER NR. 5 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 0px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-7" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']" data-width="48" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 9;text-align: center; min-width: 48px; max-width: 48px; white-space: normal; font-size: 45px; line-height: 22px; font-weight: 700; color: #dfa700; font-family:century gothic; visibility: inherit; transition: none; text-align: center; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> <i id="caret1" class="icon-heart" style="position: absolute; left: 200%;"></i></div></div></div></div>
								
								<!-- LAYER NR. 6 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 105px; z-index: 41;text-align:justify;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 65%; line-height: 22px; font-weight: 500; color: #fff;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">We provide the best-suited Wedding and Pre Wedding Venues for every occasion to make each day a memorable one. </div></div></div></div>
								</div></div></div></div> 

								<!-- LAYER NR. 7 -->
								<div  id="valet" class="tp-parallax-wrap  tp-selecttoggle tp-parallax-container" style="position: absolute; visibility: inherit; transform: matrix(1, 0, 0, 1, 0, -22.2); left: 10vh; top: 380px; z-index: 41; opacity: 1;"><div class="tp-loop-wrap" style="position:absolute;;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible;"><div class="tp-caption     rev_group rs-parallaxlevel-10 tp-withaction" id="slide-9-layer-10" data-x="['left','left','center','center']" data-hoffset="['99','49','0','114']" data-y="['top','top','top','top']" data-voffset="['360','330','60','50']" data-width="['270','270','220','220']" data-height="170" data-whitespace="nowrap" data-type="group" data-actions="[{&quot;event&quot;:&quot;mouseenter&quot;,&quot;action&quot;:&quot;startlayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-48&quot;,&quot;delay&quot;:&quot;&quot;},{&quot;event&quot;:&quot;mouseleave&quot;,&quot;action&quot;:&quot;stoplayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-48&quot;,&quot;delay&quot;:&quot;&quot;}]" data-responsive_offset="on" data-wrapper_class="tp-selecttoggle" data-frames="[{&quot;delay&quot;:800,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 11; min-width: 270px; max-width: 270px; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: #fff; font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 170px; max-height: 170px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">

								<!-- LAYER NR. 9 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 60px; z-index: 41;text-align:center;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 95%; line-height: 22px; font-weight: 500; color: #dfa700;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">Free Valet Parking</div></div></div></div>

								<!-- LAYER NR. 10 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 45px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: hidden; transform: matrix(1, 0, 0, 1, 0, 0);"><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme rev_layer_in_group" id="slide-9-layer-13" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['45','45','45','45']" data-width="['270','270','220','220']" data-height="3" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:750,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[100%];opacity:1;&quot;,&quot;mask&quot;:&quot;x:0px;y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 14; background-color: #fff; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 20px; white-space: nowrap; min-height: 3px; min-width: 270px; max-height: 3px; max-width: 270px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> </div></div></div></div>

								<!-- LAYER NR. 11 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 0px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-14" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']" data-width="48" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 15;text-align: center; min-width: 48px; max-width: 48px; white-space: normal; font-size: 45px; line-height: 22px; font-weight: 700; color: #dfa700; font-family: century gothic; visibility: inherit; transition: none; text-align: center; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> <i id="caret2" class="icon-check-sign" style="position: absolute; left: 200%;"></i></div></div></div></div>
								
								<!-- LAYER NR. 12 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 85px; z-index: 41;text-align:justify;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 65%; line-height: 22px; font-weight: 500; color: #fff;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> We specialize in offering our customers with Valet Parking facility that ensures that parking is carried out in a hassle free manner. </div></div></div></div>
								</div></div></div></div> 

								<!-- LAYER NR. 13 -->
								<div  id="meeting" class="tp-parallax-wrap  tp-selecttoggle tp-parallax-container" style="position: absolute; visibility: inherit; transform: matrix(1, 0, 0, 1, 0, -22.2); left: 10vh; top: 580px; z-index: 41; opacity: 1;"><div class="tp-loop-wrap" style="position:absolute;;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible;"><div class="tp-caption     rev_group rs-parallaxlevel-10 tp-withaction" id="slide-9-layer-16" data-x="['left','left','center','center']" data-hoffset="['100','50','240','-115']" data-y="['top','top','top','top']" data-voffset="['560','530','60','230']" data-width="['270','270','220','220']" data-height="170" data-whitespace="nowrap" data-type="group" data-actions="[{&quot;event&quot;:&quot;mouseenter&quot;,&quot;action&quot;:&quot;startlayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-49&quot;,&quot;delay&quot;:&quot;&quot;},{&quot;event&quot;:&quot;mouseleave&quot;,&quot;action&quot;:&quot;stoplayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-49&quot;,&quot;delay&quot;:&quot;&quot;}]" data-responsive_offset="on" data-wrapper_class="tp-selecttoggle" data-frames="[{&quot;delay&quot;:1000,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 17; min-width: 270px; max-width: 270px; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: #fff; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 170px; max-height: 170px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">

								<!-- LAYER NR. 15 -->
							<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 60px; z-index: 41;text-align:center;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 95%; line-height: 22px; font-weight: 500; color: #dfa700;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">Meeting Halls</div></div></div></div>

								<!-- LAYER NR. 16 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 45px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: hidden; transform: matrix(1, 0, 0, 1, 0, 0);"><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme rev_layer_in_group" id="slide-9-layer-19" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['45','45','45','45']" data-width="['270','270','220','220']" data-height="3" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:750,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[100%];opacity:1;&quot;,&quot;mask&quot;:&quot;x:0px;y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 20; background-color: #fff; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 20px; white-space: nowrap; min-height: 3px; min-width: 270px; max-height: 3px; max-width: 270px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> </div></div></div></div>

								<!-- LAYER NR. 17 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 0px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-20" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']" data-width="48" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 21;text-align: center; min-width: 48px; max-width: 48px; white-space: normal; font-size: 45px; line-height: 22px; font-weight: 700; color: #dfa700; font-family: Times New Roman; visibility: inherit; transition: none; text-align: center; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><i id="caret3" class="icon-group" style="position: absolute; left: 200%;"></i></div></div></div></div>
								
								<!-- LAYER NR. 18 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 85px; z-index: 41;text-align:justify;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 65%; line-height: 22px; font-weight: 500; color: #fff;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">For meetings and events that leave an enduring impression, there are provisions of Meeting Halls; thus bringing to every event a dedicated focus and unbridled enthusiasm.</div></div></div></div>
								</div></div></div></div> 

								<!-- LAYER NR. 19 -->
								<div  id="indoor" class="tp-parallax-wrap  tp-selecttoggle tp-parallax-container" style="position: absolute; visibility: inherit; transform: matrix(1, 0, 0, 1, 0, -22.2); right: 52vh; top: 160px; z-index: 41; opacity: 1;"><div class="tp-loop-wrap" style="position:absolute;;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible;"><div class="tp-caption     rev_group rs-parallaxlevel-10 tp-withaction" id="slide-9-layer-28" data-x="['right','right','center','center']" data-hoffset="['100','50','-240','115']" data-y="['top','top','top','top']" data-voffset="['160','130','250','230']" data-width="['270','270','220','220']" data-height="170" data-whitespace="nowrap" data-type="group" data-actions="[{&quot;event&quot;:&quot;mouseenter&quot;,&quot;action&quot;:&quot;startlayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-51&quot;,&quot;delay&quot;:&quot;&quot;},{&quot;event&quot;:&quot;mouseleave&quot;,&quot;action&quot;:&quot;stoplayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-51&quot;,&quot;delay&quot;:&quot;&quot;}]" data-responsive_offset="on" data-wrapper_class="tp-selecttoggle" data-frames="[{&quot;delay&quot;:600,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 23; min-width: 270px; max-width: 270px; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: #fff; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 170px; max-height: 170px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">

								<!-- LAYER NR. 21 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 60px; z-index: 41;text-align:center;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 95%; line-height: 22px; font-weight: 500; color: #dfa700;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">Indoor Catering</div></div></div></div>

								<!-- LAYER NR. 22 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 45px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: hidden; transform: matrix(1, 0, 0, 1, 0, 0);"><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme rev_layer_in_group" id="slide-9-layer-31" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['45','45','45','45']" data-width="['270','270','220','220']" data-height="3" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:750,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[-100%];opacity:1;&quot;,&quot;mask&quot;:&quot;x:0px;y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 26; background-color: #fff; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 20px; white-space: nowrap; min-height: 3px; min-width: 270px; max-height: 3px; max-width: 270px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> </div></div></div></div>

								<!-- LAYER NR. 23 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 0px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-32" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']" data-width="48" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:-50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 27;text-align: center; min-width: 48px; max-width: 48px; white-space: normal; font-size: 45px; line-height: 22px; font-weight: 700; color: #dfa700; font-family:century gothic; visibility: inherit; transition: none; text-align: center; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><i id="caret4" class="icon-food" style="position: absolute; left: 200%;"></i></div></div></div></div>
								
								<!-- LAYER NR. 24 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 85px; z-index: 41;text-align:justify;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 65%; line-height: 22px; font-weight: 500; color: #fff;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> We provide the thoughtfully orchestrated colours, textures and lighting throughout the room along with the best flavors and courses for meals.</div></div></div></div>
								</div></div></div></div> 

								<!-- LAYER NR. 25 -->
								<div  id="outdoor" class="tp-parallax-wrap  tp-selecttoggle tp-parallax-container" style="position: absolute; visibility: inherit; transform: matrix(1, 0, 0, 1, 0, -22.2); right: 52vh; top: 380px; z-index: 41; opacity: 1;"><div class="tp-loop-wrap" style="position:absolute;;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible;"><div class="tp-caption     rev_group rs-parallaxlevel-10 tp-withaction" id="slide-9-layer-34" data-x="['right','right','center','center']" data-hoffset="['100','50','0','-115']" data-y="['top','top','top','top']" data-voffset="['360','330','250','410']" data-width="['270','270','220','220']" data-height="170" data-whitespace="nowrap" data-type="group" data-actions="[{&quot;event&quot;:&quot;mouseenter&quot;,&quot;action&quot;:&quot;startlayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-52&quot;,&quot;delay&quot;:&quot;&quot;},{&quot;event&quot;:&quot;mouseleave&quot;,&quot;action&quot;:&quot;stoplayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-52&quot;,&quot;delay&quot;:&quot;&quot;}]" data-responsive_offset="on" data-wrapper_class="tp-selecttoggle" data-frames="[{&quot;delay&quot;:800,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 29; min-width: 270px; max-width: 270px; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: #fff; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 170px; max-height: 170px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">

								<!-- LAYER NR. 27 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 60px; z-index: 41;text-align:center;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 95%; line-height: 22px; font-weight: 500; color: #dfa700;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">Outdoor Catering</div></div></div></div>

								<!-- LAYER NR. 28 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 45px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: hidden; transform: matrix(1, 0, 0, 1, 0, 0);"><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme rev_layer_in_group" id="slide-9-layer-37" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['45','45','45','45']" data-width="['270','270','220','220']" data-height="3" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:750,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[-100%];opacity:1;&quot;,&quot;mask&quot;:&quot;x:0px;y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 32; background-color: #fff; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 20px; white-space: nowrap; min-height: 3px; min-width: 270px; max-height: 3px; max-width: 270px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> </div></div></div></div>

								<!-- LAYER NR. 29 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: -1px; top: 0px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-38" data-x="['left','left','left','left']" data-hoffset="['-1','-1','-1','-1']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']" data-width="48" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:-50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 33; text-align: center; min-width: 48px; max-width: 48px; white-space: normal; font-size: 45px; line-height: 22px; font-weight: 700; color: #dfa700; font-family: Poppins; visibility: inherit; transition: none; text-align: center; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><i id="caret5" class="icon-truck" style="position: absolute; left: 200%;"></i></div></div></div></div>
								
								<!-- LAYER NR. 30 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 85px; z-index: 41;text-align:justify;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 65%; line-height: 22px; font-weight: 500; color: #fff;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">We assure the comfort of you and your guests by ensuring the best Outdoor Catering Services along with Service staff and buffet counter decoration.</div></div></div></div>
								</div></div></div></div>

								<!-- LAYER NR. 31 -->
								<div  id="event" class="tp-parallax-wrap  tp-selecttoggle tp-parallax-container" style="position: absolute; visibility: inherit; transform: matrix(1, 0, 0, 1, 0, -22.2); right: 52vh; top: 580px; z-index: 41; opacity: 1;"><div class="tp-loop-wrap" style="position:absolute;;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible;"><div class="tp-caption     rev_group rs-parallaxlevel-10 tp-withaction" id="slide-9-layer-40" data-x="['right','right','center','center']" data-hoffset="['100','50','240','115']" data-y="['top','top','top','top']" data-voffset="['560','530','250','410']" data-width="['270','270','220','220']" data-height="170" data-whitespace="nowrap" data-type="group" data-actions="[{&quot;event&quot;:&quot;mouseenter&quot;,&quot;action&quot;:&quot;startlayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-53&quot;,&quot;delay&quot;:&quot;&quot;},{&quot;event&quot;:&quot;mouseleave&quot;,&quot;action&quot;:&quot;stoplayer&quot;,&quot;layer&quot;:&quot;slide-9-layer-53&quot;,&quot;delay&quot;:&quot;&quot;}]" data-responsive_offset="on" data-wrapper_class="tp-selecttoggle" data-frames="[{&quot;delay&quot;:1000,&quot;speed&quot;:300,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 35; min-width: 270px; max-width: 270px; white-space: nowrap; font-size: 20px; line-height: 22px; font-weight: 400; color: #fff; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 170px; max-height: 170px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">

								<!-- LAYER NR. 33 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 60px; z-index: 41;text-align:center;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 95%; line-height: 22px; font-weight: 500; color: #dfa700;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">Custom Event Decor</div></div></div></div>

								<!-- LAYER NR. 34 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 45px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: hidden; transform: matrix(1, 0, 0, 1, 0, 0);"><div class="tp-caption tp-shape tp-shapewrapper  tp-resizeme rev_layer_in_group" id="slide-9-layer-43" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['45','45','45','45']" data-width="['270','270','220','220']" data-height="3" data-whitespace="nowrap" data-type="shape" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:750,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:[-100%];opacity:1;&quot;,&quot;mask&quot;:&quot;x:0px;y:0;s:inherit;e:inherit;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 38; background-color: #fff; visibility: inherit; transition: none; text-align: inherit; line-height: 22px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 20px; white-space: nowrap; min-height: 3px; min-width: 270px; max-height: 3px; max-width: 270px; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"> </div></div></div></div>

								<!-- LAYER NR. 35 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; left: 0px; top: 0px; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-44" data-x="['left','left','left','left']" data-hoffset="['0','0','0','0']" data-y="['top','top','top','top']" data-voffset="['0','0','0','0']" data-width="48" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+0&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:-50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['center','center','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 39;text-align: center; min-width: 48px; max-width: 48px; white-space: normal; font-size: 45px; line-height: 22px; font-weight: 700; color: #dfa700; font-family: Times New Roman; visibility: inherit; transition: none; text-align: center; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><i id="caret6" class="icon-star2" style="position: absolute; left: 200%;"></i></div></div></div></div>
								
								<!-- LAYER NR. 36 -->
								<div class="tp-parallax-wrap" style="position: absolute; display: block; visibility: visible; top: 85px; z-index: 41;text-align:justify;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; overflow: visible;"><div class="tp-caption   tp-resizeme rev_layer_in_group" id="slide-9-layer-4" data-x="['left','left','left','left']" data-hoffset="['60','60','60','60']" data-y="['top','top','top','top']" data-voffset="['60','60','60','60']" data-width="['201','201','160','160']" data-height="none" data-whitespace="normal" data-type="text" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:&quot;+100&quot;,&quot;speed&quot;:500,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;x:50px;opacity:0;&quot;,&quot;to&quot;:&quot;o:1;&quot;,&quot;ease&quot;:&quot;Power4.easeOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-margintop="[0,0,0,0]" data-marginright="[0,0,0,0]" data-marginbottom="[0,0,0,0]" data-marginleft="[0,0,0,0]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 7; min-width: 251px; max-width: 251px; white-space: normal; font-size: 65%; line-height: 22px; font-weight: 500; color: #fff;  font-family:century gothic; visibility: inherit; transition: none; text-align: inherit; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; min-height: 0px; max-height: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">We specialize in designing both thematic and custom event decor that are creative, innovative, appeal to the senses and create an incredible event-surround.</div></div></div></div>
								</div></div></div></div>

								<!-- LAYER NR. 37 -->
								<div class="tp-parallax-wrap  tp-nopointer" style="position: absolute; display: block; visibility: visible; left: 6em; top: -6.5em; z-index: 41;"><div class="tp-loop-wrap" style="position:absolute;display:block;;"><div class="tp-mask-wrap" style="position: absolute; display: block; filter: blur(0px); opacity: 1; backface-visibility: hidden; transform: translate3d(72%, 67%, 0px); overflow: visible;"><div class="tp-caption   tp-resizeme  tp-nopointer " id="slide-9-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','top']" data-voffset="['0','0','200','380']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on" data-wrapper_class="tp-nopointer " data-frames="[{&quot;delay&quot;:400,&quot;speed&quot;:750,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;y:50px;opacity:0;fb:10px;&quot;,&quot;to&quot;:&quot;o:1;fb:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;fb:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="z-index: 41; visibility: inherit; transition: none; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><img id="photo-frame" src="include/rs-plugin/demos/assets/images/frame-square.png" alt="" data-no-retina="" style="width: 450px; height: 450px; background-color: #000; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px"  data-animate="bounceInDown" data-delay="500"> </div></div></div></div>

								<!-- LAYER NR. 38 -->
								<div class="tp-parallax-wrap" style=" z-index: 42; position: absolute; display: block; visibility: visible; left: 31.5em; top: 17.6em;"><div class="tp-loop-wrap" style="position:absolute;display:block;"><div class="tp-mask-wrap" style="position: absolute; display: block; filter: blur(0px); opacity: 1; backface-visibility: hidden; transform: translate3d(0px, -1px, 0px); overflow: visible;"><div class="tp-caption   tp-resizeme" id="slide-9-layer-2" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','top']" data-voffset="['0','0','199','679']" data-width="none" data-height="none" data-whitespace="nowrap" data-type="image" data-responsive_offset="on" data-frames="[{&quot;delay&quot;:400,&quot;speed&quot;:750,&quot;frame&quot;:&quot;0&quot;,&quot;from&quot;:&quot;y:50px;opacity:0;fb:10px;&quot;,&quot;to&quot;:&quot;o:1;fb:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;},{&quot;delay&quot;:&quot;wait&quot;,&quot;speed&quot;:300,&quot;frame&quot;:&quot;999&quot;,&quot;to&quot;:&quot;opacity:0;fb:0;&quot;,&quot;ease&quot;:&quot;Power3.easeInOut&quot;}]" data-textalign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" style="visibility: inherit; position: relative;  z-index: 42; transition: none;  text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; filter: blur(0px); opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><img id="piyush" src="include/rs-plugin/demos/assets/images/rpb.png" alt="" data-no-retina="" style="position: absolute; width: 353px; height: 202px;top: 6.5em; transition: all 0.3s ease-in-out; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; left:1em; letter-spacing: 0px; font-weight: 400; font-size: 14px;" data-animate="fadeIn" data-delay="500"> 

								
									<img id="wedding-image" class="image-for-section-service" src="include/rs-plugin/demos/assets/images/wedding.jpg" alt="" data-no-retina="" style=" width: 383px; height: 382px; background-color: #000; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px; z-index: 43; display: inline; opacity:0; transition: all 0.5s ease-in-out; position: absolute; transform: scale(0.7);"> 

									<img id="valet-image" class="image-for-section-service" src="include/rs-plugin/demos/assets/images/valet.jpg" alt="" data-no-retina="" style=" width: 383px; height: 382px; background-color: #000; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px;z-index: 44; display: inline; opacity:0; transition: all 0.5s ease-in-out; position: absolute; transform: scale(0.7);"> 

									<img id="meeting-image" class="image-for-section-service" src="include/rs-plugin/demos/assets/images/meeting.jpg" alt="" data-no-retina="" style=" width: 383px; height: 382px; background-color: #000; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px;z-index: 45; display: inline; opacity:0; transition: all 0.5s ease-in-out; position: absolute; transform: scale(0.7);"> 

									<img id="indoor-image" class="image-for-section-service" src="include/rs-plugin/demos/assets/images/indoor.jpg" alt="" data-no-retina="" style=" width: 383px; height: 382px; background-color: #000; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px;z-index: 46; display: inline; opacity:0; transition: all 0.5s ease-in-out; position: absolute; transform: scale(0.7);"> 
									<img id="outdoor-image" class="image-for-section-service" src="include/rs-plugin/demos/assets/images/outdoor.jpg" alt="" data-no-retina="" style=" width: 383px; height: 382px; background-color: #000; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px;z-index: 47; display: inline; opacity:0; transition: all 0.5s ease-in-out; position: absolute; transform: scale(0.7);"> 

									<img id="event-image" class="image-for-section-service" src="include/rs-plugin/demos/assets/images/events.jpg" alt="" data-no-retina="" style=" width: 383px; height: 382px; background-color: #000; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px;z-index: 48; display: inline; opacity:0; transition: all 0.5s ease-in-out; position: absolute; transform: scale(0.7);"> 

									<img id="gridview" src="include/rs-plugin/demos/assets/images/grid.png" style="width: 383px; height: 382px; text-align: inherit; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 14px;z-index: 50; display: inline; position: absolute; background:linear-gradient(rgba(0,0,0,0.3),rgba(0,0,0,0.3));"> 
									
								</div></div></div></div>

							</li>
						</ul>

					</div>
				<div class="rs-addon-polyfold rs-addon-poly-top rs-addon-poly-center"><div style="border-color: transparent rgb(255, 255, 255) transparent transparent; border-width: 0px 473px 61px 0px;"></div><div style="border-color: rgb(255, 255, 255) transparent transparent; border-width: 61px 473px 0px 0px;"></div></div><div class="rs-addon-polyfold rs-addon-poly-bottom rs-addon-poly-center"><div style="border-color: transparent transparent rgb(255, 255, 255); border-width: 0px 0px 51px 473px;"></div><div style="border-color: transparent transparent transparent rgb(255, 255, 255); border-width: 51px 0px 0px 473px;"></div></div></div><div id="full-service" class="tp-fullwidth-forcer" style="width: 100%; height: 868px;"></div></div><!-- END REVOLUTION SLIDER -->
			
		</section><!-- element 4 ends -->

		<!-- Testimonials-->
		<section id="testimonials">
			
				<div style="background:linear-gradient(rgba(0,0,0,0.8),rgba(0,0,0,0.8)),url(include/rs-plugin/demos/assets/images/test-back.jpg); background-size: 100% 100%;" class="lazy">
					<div style="position: relative;top:40px;"><h2 class="my-h1-tags" style="margin:0% 0% 2%;font-size: 300%;"> What Our Clients Say? </h2>
						<div id="carousel-slider" class="carousel slide" data-ride="carousel">
							<!-- Indicators -->
						  <!-- 	<ol class="carousel-indicators">
							    <li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
							    <li data-target="#carousel-slider" data-slide-to="1"></li>
							    <li data-target="#carousel-slider" data-slide-to="2"></li>
							    
						  	</ol> -->

							<div class="carousel-inner"  style="height:52vh;">
								<div class="item active text-center">
									<img src="include/rs-plugin/demos/assets/images/rs.jpg" class="img-circle"  alt="" style="position: relative; margin: auto;"> 
									<h3><i>"It makes our every occasion more than special"</i></h3>
									<h4 style="color:#dfa700;">-Art Of Living</h4>
									<h3>Shri Shri Ravinshankar Ji</h3>
							   </div>
							   <div class="item text-center">
									<img src="include/rs-plugin/demos/assets/images/pd.jpg" class="img-circle" alt="" style="position: relative; margin: auto;"> 
									<h3><i>"I have good memories with this place and looking forward for many more."</i></h3>
									<h4 style="color:#dfa700;">-Pidilite</h4>
							   </div> 
							   <div class="item text-center">
									<img src="include/rs-plugin/demos/assets/images/havells.jpg" class="img-circle" alt="" style="position: relative; margin: auto;"> 
									<h3><i>"Provides best form of services and satisfaction."</i></h3>
									<h4 style="color:#dfa700;">-Havells</h4>
							   </div>
							   <div class="item text-center">
									<img src="include/rs-plugin/demos/assets/images/cocacola.png" class="img-circle" alt="" style="position: relative; margin: auto;"> 
									<h3><i>"It made my corporate occassion much more delightful."</i></h3>
									<h4 style="color:#dfa700;">-Coca cola</h4>
							   </div>
							   <div class="item text-center">
									<img src="include/rs-plugin/demos/assets/images/microtek.jpg" class="img-circle" alt="" style="position: relative; margin: auto;"> 
									<h3><i>"My organised business party was a huge success in terms of service &amp; decor."</i></h3>
									<h4 style="color:#dfa700;">-Microtek</h4>
							   </div> 

							   <div class="item text-center">
									<img src="include/rs-plugin/demos/assets/images/max.png" class="img-circle" alt="" style="position: relative; margin: auto;"> 
									<h3><i>"The exemplary food and service highlighted our evening of Medical Get Together."</i></h3>
									<h4 style="color:#dfa700;">-Max Hospital</h4>
							   </div> 
							   
							</div>
							
							
							<a class="left carousel-control" href="#carousel-slider" data-slide="prev" style="margin:0px 0 10em;">
								<i class="icon-angle-left" style="color:#dfa700; left:0px;"></i> 
							</a>
							
							<a class="right carousel-control" href="#carousel-slider" data-slide="next" style="margin: 0px 0 10em;">
								<i class="icon-angle-right" style="color:#dfa700; right:0px;"></i> 
							</a>
						</div> <!--/#carousel-slider-->
						</div>
					</div><!--/#about-slider-->
			
		</section>

		
		<section id="content">

			<div class="">

				<div class="container clearfix">
					<h2 class="my-h1-tags">Our Blogs</h2>
					<!-- Posts
					============================================= -->
					<div class="blog-slider clearfix">
						<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-1.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-1.jpg" alt="go underwater just for marriage" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Go Underwater</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>If your girl enjoys adventure sports, there’s no better way to win her heart than taking her for scuba diving at Lakshadweep or the Andamans. Underwater proposals can be super fun and absolutely unexpected! Just make sure that your loved one is not struggling underwater and is obviously a trained swimmer.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-2.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-2.jpg" alt="on a romantic road trip" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>On a road trip</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Road trips are romantic and if you can take up the challenge take your loved one to the highest altitude probably in ladakh and pool off your proposal there it will surely leave them into splits. Just Make sure that you check the weather before going down on one knee – you don’t want your moment marred by heavy snowfall or landslide!</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-4.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-4.jpg" alt="hot air balloon ride in jaipur" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Hot Air Balloon ride in Jaipur</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Fancy a hot-air balloon is something you should try many resorts offer that all you have to do is to book a hot air balloon ride above the resort for extra brownie points and save the question for when you’re cozied up in the air!</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-5.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-5.jpg" alt="dream beach wedding destination in goa" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Goa</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Goa tops the list of places for romantic proposals. Imagine yourself as you kneel in the sand with the picture-perfect backdrop of an orange-pink sunset and the sound of waves gently lapping the shore in the background.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-6.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-6.jpg" alt="amidst in the valley of wedding flowers"></a>
								</div>
								<div class="entry-title">
									<h2><a>Amidst in the valley of flowers</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Die-hard romantics are known to give a flower or a bunch of flowers to their girl on every occasion to celebrate. Picture yourself asking her to marry you, while surrounded by the most beautiful flowers at the valley of flowers.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

					</div><!-- blog slider end -->
					<div align="center">
						<a href="http://royalpepperbanquets.com/banquets-update/" target="_blank" class="t400 capitalize button button-light button-circle bottommargin btn-golden"> View All Blog </a>
					</div>
				</div>

			</div>

		</section>

		<!-- Element 5
		============================================= -->
		<section id="item-5" class="slider" class="slider-parallax full-screen">

			<div class="slider-parallax-inner lazy">

				<div class="full-screen dark section nopadding nomargin noborder ohidden" style="background-image: url('images/page/form-banner.jpg'); background-size: cover; background-position: center center;">

					<div class="row nomargin" style="position: relative; z-index: 2;">
						<div class="col-md-offset-7 col-md-5 full-screen" style="background-color: rgba(0,0,0,0.45);">
							<div class="vertical-middle col-padding">
								<div class="heading-block nobottomborder bottommargin-sm">
									<h3 style="font-size: 26px;">Send Us An Email</h3>
									
								</div>
								<form action="" method="post" class="clearfix" style="max-width: 500px;">
									<div class="row">
										<div class="col-sm-6">
											<div class="col_full">
												<label class="capitalize t600">Name:*</label>
												<input type="text" id="template-op-form-name" name="txtname" value="" class="form-control not-dark" placeholder="Name" required="required">
											</div>
											<div class="col_full">
												<label class="capitalize t600">Email:*</label>
												<input type="email" id="template-op-form-email" name="txtmail" value="" class="form-control not-dark" placeholder="Email" required="required">
											</div>
											<div class="col_full">
												<label class="capitalize t600">Phone:*</label>
												<input type="number" id="template-op-form-phone" name="txtphn" value="" class="form-control not-dark" required="required" />
											</div>		
										</div>
										<div class="col-sm-6">
											<div class="col_full">
												<label class="capitalize t600">Date of Function:*</label>
												<input type="date" id="template-op-form-dof" name="txtdof" value="" class="form-control not-dark" required="required" />
											</div>
											<div class="col_full">
												<label class="capitalize t600">Expected Gathering:*</label>
												<select class="form-control not-dark" name="expectgather" required="required">
													<option>--Select--</option>
													<option>0-50</option>
													<option>50-100</option>
													<option>100-150</option>
													<option>150-200</option>
													<option>200-250</option>
													<option>250-300</option>
													<option>300-350</option>
													<option>350-400</option>
													<option>400-450</option>
													<option>450-500</option>
													<option>500+</option>
												</select>
											</div>
											<div class="col_full">
												<label class="capitalize t600">Select our Unit:*</label>
												<select class="form-control not-dark" name="selectunit" required="required">
													<option>--Select--</option>
													<option>Royal Pepper Banquets Wazirpur</option>
													<option>Royal Pepper Banquets Peeragarhi</option>
													<option>Royal Pepper Banquets Rohini Sector-3</option>
													<option>Royal Pepper Banquets Rohini Sector-10</option>
												</select>
											</div>
										</div>
									</div>
									
									
									<div class="col_full">
										
										<textarea id="template-op-form-textarea" name="txtmessage" value="" class="form-control not-dark" rows="5" placeholder="Your Message (Max. 1000 Characters)"></textarea>
									</div>
									<div class="col_full nobottommargin" style="text-align: center;">
										<button type="submit" class="t400 capitalize button button-border button-light button-circle nomargin" name="submitbig"> Submit </button>
									</div>
								</form>
								
							</div>
						</div>
					</div>

					<div class="video-wrap" style="z-index:1;">
						<div class="video-overlay" style="background: rgba(0,0,0,0.2);"></div>
					</div>

				</div>

			</div>

		</section><!-- #slider end -->

		<!-- Footer -->

	<footer id="item-6" class="footer ut-footer-dark" style="background-color: #000; ">        
        <div id="map-parent" class="ut-footer-area lazy" style="width:50%;float:left;padding-left:10%; ">
            <div style="top:100px;height:400px;margin:25px;" id="map">
    
            </div>
            
        </div>
		<div id="rpb-fb" style="width:50%;float: right;padding: 5% 12% 0%;" class="lazy">
        		<iframe id="fb-iframe" src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FRoyalPepperBanquets&tabs=timeline&width=300&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="300" height="500" style="border:none; overflow:hidden;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
     		</div>        
       
                    
        
        <div class="clear"></div>
                
            <div class="footer-content">        
                    
                <div id="rpb-copy" class="grid-container" style="margin-left:35%; height: 90px;">
                        
                    <div id="rpb-copy1" class="grid-70 prefix-15 mobile-grid-100 tablet-grid-100 topmargin-xs" style="text-align:center;">
                        <a class="text-center bottommargin-xs" href="javascript:void(0)" data-toggle="modal" data-target="#myModalcareer"><strong>Work with Us</strong></a><br>
                        <i class="icon-envelope2"></i>
                        <a class="mycolors" href="mailto:royalpepperbanquets@gmail.com"> royalpepperbanquets@gmail.com </a>
                        <span class="middot">·</span> <br class="visible-xs">
                        <i class="icon-headphones"></i> 
                        <a class="mycolors" href="tel:+918882500400" target="_blank">+91-8882-500-400 </a>
                        <br>Copyrights @ 2018 <strong>Royal Pepper Banquets</strong>.<br class="visible-xs"> <span> All Rights Reserved. </span>                        
                        <ul class="ut-footer-so topmargin-xs bottommargin-xs">
	                        <li style="display: inline-block;"><a title="facebook" href="https://www.facebook.com/RoyalPepperBanquets/" target="_blank" class="si-facebook social-icon si-small nobottommargin"><i class="icon-facebook"></i><i class="icon-facebook"></i></a></li>
	                        <li style="display: inline-block;"><a title="Twitter" href="https://twitter.com/royal_pepper" target="_blank" class="si-twitter social-icon si-small nobottommargin"><i class="icon-twitter"></i><i class="icon-twitter"></i></a></li>
	                        <li style="display: inline-block;"><a title="LinkedIN" href="https://www.linkedin.com/company-beta/13214770/" target="_blank" class="si-linkedin social-icon si-small nobottommargin"><i class="icon-linkedin "></i><i class="icon-linkedin "></i></a></li>
	                        <li style="display: inline-block;"><a title="Instagram" href="https://www.instagram.com/royalpepperbanquets/" target="_blank" class="si-instagram social-icon si-small nobottommargin"><i class="icon-instagram"></i><i class="icon-instagram"></i></a></li>
                        </ul>                    
                       <div class="bottommargin-xs"><span>Designed &amp; Developed by : <a href="http://www.wishadesign.com/" target="_blank">WAD</a></span></div>
                                
                    </div>
                            
                </div><!-- close container -->        
            </div><!-- close footer content -->
                
    </footer>
    </div>
    <div class="contact-form">
	    <form action="" method="post" style="margin:0;">
	    		<a class="btn btn-golden font-century" style="width:100%;border-radius:4px 4px 0 0;">May I Help You<span class="closing hiding" style="float: right;color: #fff;transform:scale(1.5);">&times;</span></a>
	    	<div class="hiding" id="contact-inner-div" align="center">
	    		
	    		<input class="form-control" type="text" name="txtname" placeholder="Your Name..."><br>
	    		
	    		<input class="form-control" type="number" name="txtphn" placeholder="Your Number..."><br>
	    		
	    		<input class="form-control" type="email" name="txtmail" placeholder="Your Email ID..."><br>
	    		
	    		<textarea class="form-control" rows="3" placeholder="Your Message (Max. 1000 Characters)..." name="txtmessage"></textarea><br>
	    		<input type="submit" name="submitsmall" value="Submit" class="form-control btn-golden">
	    	</div>
	   		 
	    </form>
    </div>

	<div class="hidden-xs">
		<div style="" class="feedback-form feedback1">
			<a class="btn feeback-btn btn-golden font-century" style="transform: rotate(-90deg);">Feedback </a>
			
		</div>
			
					
			<div align="center" style="" class="feedback-form feedback2">
				<h4 class="font-century">Feedback Form<span class="feedback-close">&times;</span></h4>
				<form action="" method="post" style="margin:0;">
				
					<input class="form-control" type="text" name="name" placeholder="Your Name..."><br>
					
					<input class="form-control" type="email" name="email" placeholder="Your Email ID..."><br>
					
					<textarea class="form-control" rows="4" placeholder="Your Feedback..." name="message"></textarea><br>
				
					<input type="submit" name="submitfeedback" value="Submit" class="form-control btn-golden">
				
				</form>
			</div>
				
			
		
    </div>

	<!-- modal-career starts-->

	<div id="myModalcareer" class="modal fade" role="dialog">

			<div class="modal-dialog">

				<!-- Modal content -->
	
				<div style="background: #fff;border-radius: 10px;">
	
					<div class="modal-header">
	
							<span class="close" data-dismiss="modal">&times;</span>
	
							<h2 class="modal-title" style="color: #444;">Apply for Job</h2>	    	
	
					</div>
	
					<div class="modal-body">
						<form action="" method="post" style="margin:0;">
					
							<input class="form-control input-lg" type="text" name="careername" placeholder="Your Name..."><br>
							
							<input class="form-control input-lg" type="email" name="careeremail" placeholder="Your Email ID..."><br>

							<input class="form-control input-lg" type="number" name="careernumber" placeholder="Your Phone Number...">

							<div class="alert alert-danger">
								Kindly mail your CV at <a href="https://mail.google.com/mail/u/0/#inbox?compose=new" target="_blank" class="alert-link">royalpepperbanquets@gmail.com</a>
							</div>
							
							<div align="center">
								<input type="submit" class="button button-border button-light button-rounded tcenter button-large topmargin-sm btn-golden" value="Submit" name="submitcareer">
							</div>
						
						</form>

					</div>
	
					<!-- modal-body ends-->
	
				</div>
	
				<!-- modal-content ends-->
			</div>
	
			<!-- modal-dialog ends-->

		</div>	

		<!-- modal-career ends-->
	

    <div id="gotoTop" class="icon-angle-up"></div>
		
		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/plugins.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="js/functions.js"></script>

	<!-- SLIDER REVOLUTION 5.x SCRIPTS  -->
	<script type="text/javascript" src="include/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.video.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.navigation.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.parallax.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.carousel.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.actions.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.migration.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/extensions/revolution.extension.kenburn.min.js"></script>
	<script type="text/javascript" src="include/rs-plugin/js/addons/revolution.addon.polyfold.min.js"></script>
	<!-- <script type="text/javascript" src="js/jquery.lazy.min.js"></script> -->
	<script type="text/javascript" src="js/slick.js"></script>
	
	
	<script type="text/javascript">
	jQuery(document).ready(function($){
		var t=setTimeout(function(){
			$(window).trigger('load');
			// if(SEMICOLON.isMobile.any()){
			// 	$(window).trigger('load');
			// }
		},3500);
	});
	
	$(document).ready(function(){
		$.each( $('*'), function() { 
			
			if( $(this).width() > $('body').width()) {
				var b_width=$('body').width();
				$(this).css({width : b_width});
				
			} 
		});
		/*$(function() {
	        $('.lazy').Lazy();
   	 	});*/
	});

	$(document).ready(function(){
		 setTimeout(function(){
        	$(".closing").removeClass("hiding");
			$("#contact-inner-div").removeClass("hiding");
			$("#contact-inner-div").css("background","#fff");
			$("#contact-inner-div label").css("color","#dfa700");
    	},8000);
		 
		$(".contact-form").click(function(){
			
			$(".closing").removeClass("hiding");
			$("#contact-inner-div").removeClass("hiding");
			$("#contact-inner-div").css("background","#fff");
			$("#contact-inner-div label").css("color","#dfa700");
		});
		var myclose=$('.contact-form')[0].children[0].children[0].children[0];
		$(myclose).on("mousedown",function(){
			
			$(".closing").addClass("hiding");
			$("#contact-inner-div").addClass("hiding");
			
		});
		$(".feedback1").click(function(){
			
			
			$(".feedback1").css({'transition':'all 0.5s','left':'65.5%'});
			$(".feedback2").css({'transition':'all 0.5s','left':'70%'});
		});
		$(".feedback2 span").click(function(){
			
			$(".feedback1").animate({'transition':'all 0.5s','left':'95.5%'});
			$(".feedback2").animate({'transition':'all 0.5s','left':'100%'});
		});
	});
	

	/*Banners*/
	$(document).ready(function(){
		if($(window).width()<=500){
			
			$("#banner-img1").attr("src","include/rs-plugin/demos/assets/images/rohini-mobile.jpg");
			$("#banner-img2").attr("src","include/rs-plugin/demos/assets/images/peeragarhi-mobile.jpg");
			$("#banner-img3").attr("src","include/rs-plugin/demos/assets/images/wazirpur-mobile.jpg");
			$("#service-cover").css("background","linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.7)),url(include/rs-plugin/demos/assets/images/services-mobile.jpg)");
			$("#units-back-image").css("background","linear-gradient(rgba(0,0,0,0.9),rgba(0,0,0,0.9)),url(include/rs-plugin/demos/assets/images/units-mobile.jpg)");
		}
		else{
			$("#banner-img1").attr("src","include/rs-plugin/demos/assets/images/wazirpur.jpg");
			$("#banner-img2").attr("src","include/rs-plugin/demos/assets/images/peeragarhi.jpg");
			$("#banner-img3").attr("src","include/rs-plugin/demos/assets/images/rohini.jpg");
		}
	});
	

		/*First Element JS */
		var tpj = jQuery;

		var revapi210;
		tpj(document).ready(function() {
			if (tpj("#rev_slider_210_1").revolution == undefined) {
				revslider_showDoubleJqueryError("#rev_slider_210_1");
			} else {
				revapi210 = tpj("#rev_slider_210_1").show().revolution({
					sliderType: "standard",
					jsFileLocation: "include/rs-plugin/js/",
					sliderLayout: "fullscreen",
					dottedOverlay: "none",
					navigation: {
						keyboardNavigation: "on",
						keyboard_direction: "horizontal",
						mouseScrollNavigation: "off",
						onHoverStop: "off",
						arrows: {
							style: "uranus",
							enable: true,
							hide_onmobile: false,
							hide_onleave: false,
							tmp: '',
							left: {
								h_align: "center",
								v_align: "bottom",
								h_offset: -30,
								v_offset: 60
							},
							right: {
								h_align: "center",
								v_align: "bottom",
								h_offset: 30,
								v_offset: 60
							}
						}
					},
					responsiveLevels: [1240, 1024, 778, 480],
					visibilityLevels: [1240, 1024, 778, 480],
					gridwidth: [1240, 1024, 778, 480],
					gridheight: [768, 668, 960, 720],
					parallax: {
						type: "3D",
						origo: "slidercenter",
						speed: 800,
						levels: [50, 10, 8, 15, 20, 30, 35, 40, 0, 50, 47, 48, 49, 50, 51, 55],
						type: "3D",
						ddd_shadow: "off",
						ddd_bgfreeze: "off",
						ddd_overflow: "hidden",
						ddd_layer_overflow: "visible",
						ddd_z_correction: 65,
					},
					spinner: "on",
					stopLoop: "on",
					stopAfterLoops: 100,
					stopAtSlide: 1,
					shuffle: "off",
					autoHeight: "off",
					fullScreenAutoWidth: "off",
					fullScreenAlignForce: "off",
					fullScreenOffsetContainer: "",
					fullScreenOffset: "60px",
					disableProgressBar: "on",
					hideThumbsOnMobile: "off",
					hideSliderAtLimit: 0,
					hideCaptionAtLimit: 0,
					hideAllCaptionAtLilmit: 0,
					debugMode: false,
					fallbacks: {
						simplifyAll: "off",
						nextSlideOnWindowFocus: "off",
						disableFocusListener: false,
					}
				});
			}
		}); /*ready*/
		
		/*Second Element JS */
		
		jQuery(document).ready(function($){
			
			$('.videoplay-on-hover').hover( function(){			
				var unit= $(this).attr("id");
				$(this).find(".video-overlay").fadeOut();
				switch(unit){
					case "wazir-a"	: 	
										$("#wazir-h2").fadeOut();
										$("#rohini-a").find('video').get(0).pause();
										$("#peera-a").find('video').get(0).pause();
										break;
					case "rohini-a" : 	
										$("#rohini-h2").fadeOut();
										$("#wazir-a").find('video').get(0).pause();
										$("#peera-a").find('video').get(0).pause();
										break;
					case "peera-a" : 	
										$("#peera-h2").fadeOut();
										$("#rohini-a").find('video').get(0).pause();
										$("#wazir-a").find('video').get(0).pause();
										break;
				}
				if( $(this).find('video').length > 0 ) {
					$(this).find('video').get(0).play();
				}
			}, function(){
				$("#wazir-h2").fadeIn();
				$("#rohini-h2").fadeIn();
				$("#peera-h2").fadeIn();
				$(this).find(".video-overlay").fadeIn();
				if( $(this).find('video').length > 0 ) {
					$(this).find('video').get(0).pause();
				}
			});
		});

		// (function(){
		//     $('.flex-container').waitForImages(function() {
		//       $('.spinner').fadeOut();
		//   	}, $.noop, true);
		  
		//   $(".flex-slide").each(function(){
		//     $(this).hover(function(){
		//       $(this).find('.flex-title').css({
		//         transform: 'rotate(0deg)',
		//         top: '10%'
		//       });
		//       $(this).find('.flex-about').css({
		//         opacity: '1'
		//       });
		//     }, function(){
		//       $(this).find('.flex-title').css({
		//         transform: 'rotate(90deg)',
		//         top: '15%'
		//       });
		//       $(this).find('.flex-about').css({
		//         opacity: '0'
		//       });
		//     })
		//   });
		// })();


		
		/*Third Element JS */
		var tpj=jQuery;
		var revapi108;
		tpj(document).ready(function() {
			if(tpj("#rev_slider_108_1").revolution == undefined){
				revslider_showDoubleJqueryError("#rev_slider_108_1");
			}else{
				revapi108 = tpj("#rev_slider_108_1").show().revolution({
					sliderType:"carousel",
					jsFileLocation:"include/rs-plugin/js/",
					sliderLayout:"fullwidth",
					dottedOverlay:"none",
					delay:9000,
					navigation: {
						keyboardNavigation:"off",
						keyboard_direction: "horizontal",
						mouseScrollNavigation:"off",
						onHoverStop:"off",
						arrows: {
							style:"metis",
							enable:true,
							hide_onmobile:false,
							hide_under:768,
							hide_onleave:false,
							tmp:'',
							left: {
								h_align:"left",
								v_align:"center",
								h_offset:0,
								v_offset:0
							},
							right: {
								h_align:"right",
								v_align:"center",
								h_offset:0,
								v_offset:0
							}
						}
						,
						thumbnails: {
							style:"erinyen",
							enable:true,
							width:150,
							height:100,
							min_width:150,
							wrapper_padding:20,
							wrapper_color:"#000000",
							wrapper_opacity:"0.05",
							tmp:'<span class="tp-thumb-image"></span>',
							visibleAmount:9,
							hide_onmobile:false,
							hide_onleave:false,
							direction:"horizontal",
							span:true,
							position:"outer-bottom",
							space:10,
							h_align:"center",
							v_align:"bottom",
							h_offset:0,
							v_offset:0
						}
					},
					carousel: {
						maxRotation: 65,
						vary_rotation: "on",
						minScale: 55,
						vary_scale: "off",
						horizontal_align: "center",
						vertical_align: "center",
						fadeout: "on",
						vary_fade: "on",
						maxVisibleItems: 5,
						infinity: "on",
						space: -150,
						stretch: "off"
					},
					gridwidth:600,
					gridheight:600,
					lazyType:"none",
					shadow:0,
					spinner:"off",
					stopLoop:"on",
					stopAfterLoops:10,
					stopAtSlide:1,
					shuffle:"off",
					autoHeight:"off",
					disableProgressBar:"on",
					hideThumbsOnMobile:"off",
					hideSliderAtLimit:0,
					hideCaptionAtLimit:0,
					hideAllCaptionAtLilmit:0,
					debugMode:false,
					fallbacks: {
						simplifyAll:"off",
						nextSlideOnWindowFocus:"off",
						disableFocusListener:false,
					}
				});
			}
		});	/*ready*/
		
		
		/* Element 4 JS */
		
		$(document).ready(function(){
			$("#caret1","#caret2","#caret3","#caret4","#caret5","#caret6").hover(function(){
				$(this).animate({transform:scale(1.2)},"slow");
			});
		});

		var tpj=jQuery;
		var revapi5;
		tpj(document).ready(function() {
			if(tpj("#rev_slider_5_1").revolution == undefined){
				revslider_showDoubleJqueryError("#rev_slider_5_1");
			}else if($(window).width()<=500){
				$("gridview").css("display","none");
				
			}
			else{
				revapi5 = tpj("#rev_slider_5_1").show().revolution({
					sliderType:"hero",
					jsFileLocation:"include/rs-plugin/js/",
					sliderLayout:"fullwidth",
					dottedOverlay:"none",
					delay:9000,
					navigation: {
					},
					responsiveLevels:[1240,1024,778,480],
					visibilityLevels:[1240,1024,778,480],
					gridwidth:[1240,1024,778,480],
					gridheight:[868,768,1080,1280],
					lazyType:"none",
					scrolleffect: {
						fade:"on",
						blur:"on",
						maxblur:"20",
						on_layers:"on",
						direction:"top",
						multiplicator_layers:"1.6",
						tilt:"10",
					},
					parallax: {
						type:"scroll",
						origo:"slidercenter",
						speed:400,
						levels:[5,10,15,20,25,30,35,40,-5,-10,-15,-20,-25,-30,-35,55],
						disable_onmobile:"on"
					},
					shadow:0,
					spinner:"off",
					autoHeight:"off",
					disableProgressBar:"on",
					hideThumbsOnMobile:"off",
					hideSliderAtLimit:0,
					hideCaptionAtLimit:0,
					hideAllCaptionAtLilmit:0,
					debugMode:false,
					fallbacks: {
						simplifyAll:"off",
						disableFocusListener:false,
					}
				});
				//Fade out not Focused Elements on Hover
				jQuery('body').on('mouseenter','.tp-selecttoggle',function() {
				  jQuery(this).addClass("selected");			  			 
				  var elemID=$(this).attr("id");
				  switch(elemID){
				  	case "wedding": 			  					
								 $(".active-image-section-service").removeClass("active-image-section-service");
				  				 $("#"+elemID+"-image").addClass("active-image-section-service"); 
				  				 break;
				  	case "valet": 
								 $(".active-image-section-service").removeClass("active-image-section-service");
				  				 $("#"+elemID+"-image").addClass("active-image-section-service");
				  				 break;
				  	case "meeting": 
								 $(".active-image-section-service").removeClass("active-image-section-service");
				  				 $("#"+elemID+"-image").addClass("active-image-section-service");
				  				 break;
				  	case "indoor": 
								 $(".active-image-section-service").removeClass("active-image-section-service");
				  				 $("#"+elemID+"-image").addClass("active-image-section-service"); 
				  				 break;
				  	case "outdoor": 
								 $(".active-image-section-service").removeClass("active-image-section-service");
				  				 $("#"+elemID+"-image").addClass("active-image-section-service"); 
				  				 break;
				  	case "event": 
								 $(".active-image-section-service").removeClass("active-image-section-service");
				  				 $("#"+elemID+"-image").addClass("active-image-section-service");
				  				 break;
				  }
				  
				  jQuery('.tp-selecttoggle').each(function() {
					var _ = jQuery(this);				
					if (!_.hasClass("selected")) punchgs.TweenLite.to(_,0.8,{autoAlpha:0.35,ease:punchgs.Power2.easeInOut,overwrite:"auto"});	
				  }); 
				});

				//Fade in all Elements on Blur
				jQuery('body').on('mouseleave','.tp-selecttoggle',function() {
				  jQuery(this).removeClass("selected");
				  var elemID=$(this).attr("id");
				  switch(elemID){
				  	case "wedding": 
	 
				  				 $("#"+elemID+"-image").removeClass("active-image-section-service");			
				  				 break;
				  	case "valet": 
								 
				  				 $("#"+elemID+"-image").removeClass("active-image-section-service");
				  				 break;
				  	case "meeting": 
								 
				  				 $("#"+elemID+"-image").removeClass("active-image-section-service");
				  				 break;
				  	case "indoor": 
								 
				  				 $("#"+elemID+"-image").removeClass("active-image-section-service");
				  				 break;
				  	case "outdoor": 
								 
				  				 $("#"+elemID+"-image").removeClass("active-image-section-service");
				  				 break;
				  	case "event": 
								 
				  				 $("#"+elemID+"-image").removeClass("active-image-section-service");
				  				 break;
				  }
				  	
				  jQuery('.tp-selecttoggle').each(function() {
					var _ = jQuery(this);
					punchgs.TweenLite.to(_,0.8,{autoAlpha:1,ease:punchgs.Power2.easeInOut,overwrite:"auto"});
				  });
				});
			}
			RsPolyfoldAddOn(tpj, revapi5,{position: "top", color: "#ffffff", scroll: true, height: 150, range: "slider", point: "center", placement: 1, responsive: true, negative: true, leftWidth: 0.35, rightWidth: 0.35, inverted: false, animated: false});
			RsPolyfoldAddOn(tpj, revapi5,{position: "bottom", color: "#ffffff", scroll: true, height: 150, range: "slider", point: "center", placement: 1, responsive: true, negative: true, leftWidth: 0.35, rightWidth: 0.35, inverted: false, animated: false});
		});/*ready*/
	
	</script>

	<script>
		$('.blog-slider').slick({
	      //dots: true,
	      infinite: true,
	      centerMode: false,
	      arrows: false,
	      pauseOnFocus: false,
	      centerPadding: '0%',
	      slidesToShow: 3,
	      speed: 500,
	      autoplay: true,
	      autoplaySpeed: 1500,
	      // responsive: [{

	      //       breakpoint: 992,
	      //       settings: {
	      //         slidesToShow: 1
	      //       }

	      //     }]
	      responsive: [
	        {
	          breakpoint: 1024,
	          settings: {
	            slidesToShow: 3
	          }
	        },
	        {
	          breakpoint: 780,
	          settings: {
	            slidesToShow: 2
	          }
	        },
	        {
	          breakpoint: 600,
	          settings: {
	            slidesToShow: 1
	          }
	        }

	      ]
	    });

	</script>
	

	<script>

			/*Maps*/

      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: {lat: 28.7, lng: 77.145},
		  styles: [
    {
        "featureType": "all",
        "elementType": "labels.text.fill",
        "stylers": [
            {
                "saturation": 36
            },
            {
                "color": "#333333"
            },
            {
                "lightness": 40
            }
        ]
    },
    {
        "featureType": "all",
        "elementType": "labels.text.stroke",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "color": "#ffffff"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "all",
        "elementType": "labels.icon",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#fefefe"
            },
            {
                "lightness": 17
            },
            {
                "weight": 1.2
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f7f2ed"
            },
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "landscape.natural.landcover",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#000000"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f5f5f5"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#dedede"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 17
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 29
            },
            {
                "weight": 0.2
            }
        ]
    },
    {
        "featureType": "road.arterial",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 18
            }
        ]
    },
    {
        "featureType": "road.local",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "transit",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f2f2f2"
            },
            {
                "lightness": 19
            }
        ]
    },
    {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#cbf2f2"
            }
        ]
    }
]
        });

        setMarkers(map);
      }
      var rpb = [
        ['Wazirpur', 28.704734,77.172242, 4],
		['Rohini Sec-3', 28.703657,77.108054, 3],
		['Peeragarhi', 28.708136,77.124667, 2],
		['Rohini Sec-10', 28.706755,77.105493, 1]
      ];

      function setMarkers(map) {
       
        for (var i = 0; i < rpb.length; i++) {
          var myunits = rpb[i];
          var marker = new google.maps.Marker({
            position: {lat: myunits[1], lng: myunits[2]},
            map: map,
           	icon: 'images/11.png',
			html:	myunits[0],
            title: myunits[0],
            zIndex: myunits[3]
          });
        }
      }
    </script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAJX5xXhBvqGPED4CMcoTGmGCTcqX99JH4&callback=initMap">
    </script>
	<!-- <script language="text/javascript">
		document.onmousedown=disableclick;
		var status="Give Respect To code and its Developer! :)";
		function disableclick(event){ 
			if(event.button==2) { 
				alert(status); 
				return false;
			}
		}
</script> -->
</body>
</html>