<?php
include 'configuration.php';
	header('Access-Control-Allow-Origin: *');
	date_default_timezone_set("Asia/Kolkata");
	$data=array();
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
	
	//SELECT IF(la='true','L','') AS laaa,IF(`dd`='true','D','') AS laa1 FROM midday
        $getdata = file_get_contents("php://input");
        $request = json_decode($getdata);
		$myDate=$request->myDate1;	
	//date("d-M-Y",strtotime($row['ord_date']))
	
	$q="select location_id,IF(la='true','L','') AS l1,IF(da='true','D','') AS D1,IF(lb='true','L','') AS l2,
	IF(db='true','D','') AS D2,IF(lc='true','L','') AS l3,IF(dc='true','D','') AS D3,IF(ld='true','L','') AS l4,IF(dd='true','D','') AS D4 from midday where m_date='".$myDate."'";
	
	
		$s2=mysqli_query($con,$q);
		$n=mysqli_num_rows($s2);
		
		//echo json_encode("q==".$q."n==".$n);
		
		//$data1=array( 'programms1'=> array("id" => "1","about"=>"about"),'programms2' => array("id"=> "1","name"=> "name"));
		
	
		
	
				$i=0;	
		while($r=mysqli_fetch_array($s2))
		{
				//unset($data);
				
				$data['floor'.$r['location_id']]= 
				 array("laa" => $r['l1'],"daa" => $r['D1'],"lbb" => $r['l2'],"dbb" => $r['D2'],"lcc" => $r['l3'],
				"dcc" => $r['D3'],"ldd" => $r['l4'],"ddd" => $r['D4']
				
				);
				
		
		$i++;
		
		} // end of 
		
		echo json_encode($data);
		
		
		
}
?>