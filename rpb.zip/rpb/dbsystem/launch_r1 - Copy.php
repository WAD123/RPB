<?php
include 'configuration.php';
	header('Access-Control-Allow-Origin: *');
	date_default_timezone_set("Asia/Kolkata");
		$s2=mysqli_query($con,"select * from midday where location_id='1' and m_date='".date("Y-m-d")."'");
		$n=mysqli_num_rows($s2);
		
		 $data[] = array(
       
        'laa' => '0',
		'daa' =>  '0',
		'lbb' =>  '0',
		'dbb' =>  '0',
		'lcc' =>  '0',
		'dcc' =>  '0',
		'ldd' =>  '0',
		'ddd' =>  '0'
    	);	
		while($r=mysqli_fetch_array($s2))
		{
		unset($data);
		   $data[] = array(
       
        'laa' => $r['la'],
		'daa' => $r['da'],
		'lbb' => $r['lb'],
		'dbb' => $r['db'],
		'lcc' => $r['lc'],
		'dcc' => $r['dc'],
		'ldd' => $r['ld'],
		'ddd' => $r['dd']
    	);	
		
		
		} // end of 
		if($s2){
		    //$result = '{"success":true, "data":"' .json_encode($data).'"}';   
		echo json_encode($data);           
			//echo json_encode($result);       
			
		}
		else {
    		$result = "{'success':false}";
			echo json_encode($result);
		}	
?>