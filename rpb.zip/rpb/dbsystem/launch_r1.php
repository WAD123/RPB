<?php
include 'configuration.php';
	header('Access-Control-Allow-Origin: *');
	date_default_timezone_set("Asia/Kolkata");
	
	if ($_SERVER['REQUEST_METHOD'] === 'POST') 
	{
        $getdata = file_get_contents("php://input");
        $request = json_decode($getdata);
		$myDate=$request->myDate1;	
	
		$s2=mysqli_query($con,"select * from midday where location_id='1' and m_date='".date("Y-m-d",strtotime($myDate))."'");
		$n=mysqli_num_rows($s2);
		
		 $data[] = array(
       
        'laa' => 'false',
		'daa' =>  'false',
		'lbb' =>  'false',
		'dbb' =>  'false',
		'lcc' =>  'false',
		'dcc' =>  'false',
		'ldd' =>  'false',
		'ddd' =>  'false'
    	);	
		while($r=mysqli_fetch_array($s2))
		{
		unset($data);
		   $data[] = array(
       
        'laa' => $r['la'],
		'daa' => $r['da'],
		'lbb' => $r['lb'],
		'dbb' => $r['db'],
		'lcc' => $r['lc'],
		'dcc' => $r['dc'],
		'ldd' => $r['ld'],
		'ddd' => $r['dd']
    	);	
		
		
		} // end of  while loop
		if($s2){
		     
		echo json_encode($data);           
			    
			
		}
	
	}	
?>