<?php
include 'configuration.php';
header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
        $postdata = file_get_contents("php://input");
        $request = json_decode($postdata);
     	$user=$request->username;
		$pass=$request->pass;
		$s=mysqli_query($con,"select * from login where login_usr='".$user."' and login_pass='".$pass."'");
		$r=mysqli_fetch_array($s);
		$n=mysqli_num_rows($s);
		if($n==0)
		{
		echo json_encode("incorrect");
		}
		else
		{
			echo json_encode($r['login_type']);
			
		}
}
else
{
    echo "Not allowed";
}
?>