<?php
include 'configuration.php';
header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
        $postdata = file_get_contents("php://input");
        $request = json_decode($postdata);

	$s2=mysqli_query($con,"delete from midday ");
}
echo json_encode(" Updated Successfully");
?>


