<?php
include 'configuration.php';
function sendfcm($regdata,$msgbody){
$url = 'https://fcm.googleapis.com/fcm/send';
$server_key = 'AAAAEVn0BoY:APA91bFlNRA9Y1d7SxQTDnhVvC0_lcI6JS0m-4lvvYTcO8qM9n13P4QYv7zyLRnsRdYvO5tzrI1h-nnD6pth5AeKG_QFC2uNlYUCSsYk4bJgIxdnZgF_9ar4l8fceTuexBnbDjEZlzTu';

$msg = array
(
    'body'  => $msgbody,
    'title'     => 'Booked For: '.$regdata,
    'vibrate'   => 1,
    'sound'     => 1,
);

$fields = array
(
    'to'  => '/topics/all',
    'notification'      => $msg
);



$headers = array(
	'Content-Type:application/json',
  'Authorization:key='.$server_key
);

$ch = curl_init();
curl_setopt( $ch,CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send' );
curl_setopt( $ch,CURLOPT_POST, true );
curl_setopt( $ch,CURLOPT_HTTPHEADER, $headers );
curl_setopt( $ch,CURLOPT_RETURNTRANSFER, true );
curl_setopt( $ch,CURLOPT_SSL_VERIFYPEER, false );
curl_setopt( $ch,CURLOPT_POSTFIELDS, json_encode( $fields ) );
$result = curl_exec($ch);
if ($result === FALSE) {
	die('FCM Send Error: ' . curl_error($ch));
}
curl_close($ch);



}
	$s2=mysqli_query($con,"delete from midday where  DATE(m_date)<'".date("Y-m-d")."'");

?>


