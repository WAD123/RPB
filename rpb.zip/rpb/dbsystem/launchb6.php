<?php
include 'configuration.php';include 'firebase.php';
header('Access-Control-Allow-Origin: *');
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
        $postdata = file_get_contents("php://input");
        $request = json_decode($postdata);
     	$launch1=$request->launch1;
		$location_id=$request->location_id;
		$myDate=$request->myDate;
		
		$typebook='Lunch';
		$floor="1";
		if(	$location_id==5)
		{$floor='G';}
		$regdata=date("Y-m-d",strtotime($myDate));
		$msg="Loc ".$location_id.$floor." ".$typebook;
				
		$s2=mysqli_query($con,"select * from midday where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."'");
		$n=mysqli_num_rows($s2);
		if($n==0)
		{			
			if($launch1==1)
			{
		mysqli_query($con,"insert into midday set location_id='".$location_id."',	ld_back='true',m_date='".date("Y-m-d",strtotime($myDate))."'");
			sendfcm($regdata,$msg." Booked");
		echo json_encode(" Update successfully ");
		
			}
		}
		else
		{
			if($launch1 =='')
			{
			mysqli_query($con,"update midday set 	ld_back='false' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."' ");
				sendfcm($regdata,$msg." UnBooked");
			echo json_encode("  Update Successfully ");
			}
			else
			{
			mysqli_query($con,"update midday set 	ld_back='true' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."' ");
				sendfcm($regdata,$msg." Booked");
			echo json_encode(" Update Successfully ");
			}
		}		
}
?>