<?php
$host="localhost";
$username="root";
$password="wad@root123";
$dbname="mahiway_launch";
$con=mysqli_connect($host,$username,$password,$dbname);
?>