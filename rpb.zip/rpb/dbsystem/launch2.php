<?php

include 'configuration.php';
header('Access-Control-Allow-Origin: *');

if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
       $postdata = file_get_contents("php://input");
        $request = json_decode($postdata);
		
		 $truet=json_decode($postdata);
		 
		 $togglevalue=$truet->togglevalue;
		
	
		
		 $location_id=$request->location_id;
		 $colname=$request->colname;
		 $myDate=$request->myDate;
		
			echo json_encode("Update Successfully !!toggle==".$togglevalue);	
		
		
/*	$s2=mysqli_query($con,"select * from midday where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."'");
		$n=mysqli_num_rows($s2);
		if($n==0)
		{
			if($colname =='l1')
			{
				$q="insert into midday set location_id='".$location_id."',la='true',m_date='".date("Y-m-d",strtotime($myDate))."'";
		mysqli_query($con,$q);
		echo json_encode("Add Successfully !");
			}
			if($colname =='l2')
			{
		$q="insert into midday set location_id='".$location_id."',lb='true',m_date='".date("Y-m-d",strtotime($myDate))."'";
		mysqli_query($con,$q);
		echo json_encode("Add Successfully !");
			}
		
			if($colname =='d1')
			{
				
		$q="insert into midday set location_id='".$location_id."',da='true',m_date='".date("Y-m-d",strtotime($myDate))."'";
		mysqli_query($con,$q);
		echo json_encode("Add Successfully !");
			}
			if($colname =='d2')
			{
			$q="insert into midday set location_id='".$location_id."',db='true',m_date='".date("Y-m-d",strtotime($myDate))."'";
		mysqli_query($con,$q);
		echo json_encode("Add Successfully !");	
			}
		
		
		}
		else
		{
			if($togglevalue =='0')
			{
				// set false
				if($colname=='l1')
				{
			mysqli_query($con,"update midday set la='false' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."'");
			echo json_encode("Update Successfully !");
				}
				if($colname=='l2')
				{
			mysqli_query($con,"update midday set lb='false' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."'");
			echo json_encode("Update Successfully !");
					
				}
				if($colname=='d1')
				{
			mysqli_query($con,"update midday set da='false' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."' ");
			echo json_encode("Update Successfully !");
				}
				if($colname=='d2')
				{
		mysqli_query($con,"update midday set db='false' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."' ");
			echo json_encode("Update Successfully !");
				}
				
			
			}
			if($togglevalue =='1')
			{
				
				//  set true
				if($colname=='l1')
				{
			mysqli_query($con,"update midday set la='true' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."'");
			echo json_encode("Update Successfully ");
				}
				if($colname=='l2')
				{
			mysqli_query($con,"update midday set lb='true' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."'");
			echo json_encode("Update Successfully ");
				}
				if($colname=='d1')
				{
				mysqli_query($con,"update midday set da='true' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."'");
			echo json_encode("Update Successfully ");	
				}
				if($colname=='d2')
				{
			mysqli_query($con,"update midday set db='true' where location_id='".$location_id."' and m_date='".date("Y-m-d",strtotime($myDate))."'");
			echo json_encode("Update Successfully ");
				}
				
				
			} // end $togglevalue =='1';
		
			
			else
			{
			echo json_encode("Update Successfully !!toggle==".$togglevalue);	
			}
			
			
		} // end of else variable $n */
		
}

?>

