<?php

include 'configuration.php';include 'firebase.php';
error_reporting(E_ALL); ini_set('display_errors', 1);
		sendfcm("2017-11-1","this has been Booked");
	

?>