<?php
include 'configuration.php';
	header('Access-Control-Allow-Origin: *');
	date_default_timezone_set("Asia/Kolkata");
	$data=array();
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
	
	//SELECT IF(la='true','L','') AS laaa,IF(`dd`='true','D','') AS laa1 FROM midday
        $getdata = file_get_contents("php://input");
        $request = json_decode($getdata);
		$myDate=$request->myDate1;	
	//date("d-M-Y",strtotime($row['ord_date']))
	
	$q="select location_id,IF(la='true','X','') AS l1,IF(da='true','Y','') AS D1,IF(lb='true','X','') AS l2,
	IF(db='true','Y','') AS D2,IF(lb_back='true','X','') AS lb_back,IF(db_back='true','Y','') AS db_back,IF(lc='true','X','') AS l3,IF(dc='true','Y','') AS D3,IF(lc_back='true','X','') AS lc_back,IF(dc_back='true','Y','') AS dc_back,IF(ld='true','X','') AS l4,IF(ld_back='true','X','') AS ld_back,IF(dd='true','Y','') AS D4,IF(dd_back='true','Y','') AS dd_back from midday where m_date='".date("Y-m-d",strtotime($myDate))."'";	
		$s2=mysqli_query($con,$q);
		$n=mysqli_num_rows($s2);		
		//echo json_encode("q==".$q."n==".$n);		
		//$data1=array( 'programms1'=> array("id" => "1","about"=>"about"),'programms2' => array("id"=> "1","name"=> "name"));
				$i=0;	
		while($r=mysqli_fetch_array($s2))
		{
				//unset($data);
				
				$data['floor'.$r['location_id']]= 
				 array("laa" => $r['l1'],"daa" => $r['D1'],"lbb" => $r['l2'],"dbb" => $r['D2'],"lbback" => $r['lb_back'],"dbback" => $r['db_back'],"lcc" => $r['l3'],
				"dcc" => $r['D3'],"ldd" => $r['l4'],"ddd" => $r['D4'],"lcback" => $r['lc_back'],"dcback" => $r['dc_back'],"ldback" => $r['ld_back'],
				"ddback" => $r['dd_back']
				);
				
		
		$i++;
		
		} // end of 
		
		echo json_encode($data);
		
		
}
?>