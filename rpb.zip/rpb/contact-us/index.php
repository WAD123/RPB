<!DOCTYPE html>
<html lang="en">
<head>
	<?php
		if(isset($_POST['submitbig'])){
			$name=$_REQUEST['txtname'];
			$phn=$_REQUEST['txtphn'];
			$email=$_REQUEST['txtmail'];
			$dof=$_REQUEST['txtdof'];
			$gather=$_REQUEST['expectgather'];
			$unit=$_REQUEST['selectunit'];
			$msg=$_REQUEST['txtmessage'];

			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Feedback";
			$txt = "Customer Name: ".$name."."."\r\n"."Customer Phone Number: ".$phn."."."\r\n"."Date of function: ".$dof."."."\r\n"."Expected Gathering: ".$gather."."."\r\n"."Unit: ".$unit."."."\r\n"."Customer Message: ".$msg;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);
				
			$link=mysqli_connect("localhost","root","wad@root123","royal_pepper");

			if (!$link) {
				 ?>
			   <script>alert("Connection Failed. There is some problem.");</script>
			    <?php
			    
			}

			$sql = "INSERT INTO contactform_big(Cust_Name,Email,Phone,Date_Of_Function,Expect_Gather,Unit,Message) VALUES ('".$name."','".$email."','".$phn."','".$dof."','".$gather."','".$unit."','".$msg."')";

			if (mysqli_query($link, $sql)) {
					  ?>
	    			    <script>alert("Your details have been submitted. We will get back to you soon.");</script>
	   				 <?php
	   				 

			} else {
			    ?>
			   <script>alert("There is some problem.");</script>
			    <?php
			   
			}

			mysqli_close($link);
		}
		
		if(isset($_POST['submitsmall'])){
			$name=$_REQUEST['txtname'];
			$phn=$_REQUEST['txtphn'];
			$email=$_REQUEST['txtmail'];
			$msg=$_REQUEST['txtmessage'];
			
			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Feedback";
			$txt = "Customer Name: ".$name."."."\r\n"."Customer Phone Number: ".$phn."."."\r\n"."Customer Message: ".$msg;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);

				$link1=mysqli_connect("localhost","root","wad@root123","royal_pepper");

				if (!$link1) {
				 ?>
			   <script>alert("Connection Failed. There is some problem.");</script>
			    <?php
			    
			}

			$sql = "INSERT INTO contactform_small(Cust_Name,Phone,Email,Message) VALUES ('".$name."','".$phn."','".$email."','".$msg."')";

			if (mysqli_query($link1, $sql)) {
				  ?>
	    			    <script>alert("Your details have been submitted. We will get back to you soon.");</script>
	   			 <?php
	   			
				
			} else {
				 ?>
			   <script>alert("There is some problem.");</script>
			    <?php
			   
			}

			mysqli_close($link1);

		}
	?>

	<!-- Google Tag Manager -->
	<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
	new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
	j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
	'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
	})(window,document,'script','dataLayer','GTM-PPJWK7G');</script>
	<!-- End Google Tag Manager -->

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta http-equiv="content-type" content="text/html">
	<meta name="description" content="">
	<meta name="keywords" content="">
	
	<!-- Stylesheets
	============================================= -->
	

	<!-- MY CSS -->
	<link rel="stylesheet" href="../css/mystyle.css" type="text/css" />
	
	<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="../css/style.css" type="text/css" />
	<link rel="stylesheet" href="../css/main.css" type="text/css">
	<!-- One Page Module Specific Stylesheet -->
	<link rel="stylesheet" href="../css/onepage.css" type="text/css" />
	
	
	<link rel="stylesheet" href="../css/dark.css" type="text/css" />
	<link rel="stylesheet" href="../css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="../css/et-line.css" type="text/css" />
	<link rel="stylesheet" href="../css/animate.css" type="text/css" />
	<link rel="stylesheet" href="../css/magnific-popup.css" type="text/css" />
	
	<link rel="stylesheet" href="../css/fonts.css" type="text/css" />

	<link rel="stylesheet" href="../css/responsive.css" type="text/css" />
		
	<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
	<![endif]-->

	<!-- SLIDER REVOLUTION 5.x CSS SETTINGS -->
	<link rel="stylesheet" type="text/css" href="../include/rs-plugin/css/settings.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="../include/rs-plugin/css/layers.css">
	<link rel="stylesheet" type="text/css" href="../include/rs-plugin/css/navigation.css">
	
	
	<link rel="icon" href="../include/rs-plugin/demos/assets/images/rpb.png">


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106006908-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-106006908-1');
</script>

<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 822487020;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/822487020/?guid=ON&amp;script=0"/>
</div>
</noscript>


	</head>

	<!-- Document Title
	============================================= -->
	<title>Contact Us | Royal Pepper Banquets </title>

	
	<link id="swcolors-Css" rel="stylesheet" href="../css/colors.css" type="text/css">

</head>

<body class="stretched" style="overflow-x:hidden;" data-loader="4">
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PPJWK7G"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->


	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		<header id="header" class="full-header" data-sticky-class="not-dark">

			<div id="header-wrap">

				<div class="container clearfix">

					<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="http://www.royalpepperbanquets.com" class="standard-logo"><img src="../images/logo.png" alt="RPB Logo"></a>
						<a href="http://www.royalpepperbanquets.com" class="retina-logo"><img src="../images/logo.png" alt="RPB Logo"></a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu">

						<ul>
							<li><a href="http://www.royalpepperbanquets.com"><div>Home</div></a>
								
							</li>
							<li><a href="http://www.royalpepperbanquets.com/#units"><div>Our Units</div></a>
								<ul>
									<li class="sub-menu"><a href="/peeragarhi/" data-toggle="tooltip" data-placement="right" title="Place of Dreams Banquets"><div>RPB Peeragarhi</div></a>
										
									</li>
										
									
									<li class="sub-menu"><a href="/wazirpur/"><div>RPB Waziprpur </div></a>
										
									</li>
									<li class="sub-menu"><a href="/rohini/"><div>RPB Rohini</div></a>
										<ul>
											<li class="sub-menu"><a href="/rohini/"><div>RPB Rohini Sec-3</div></a></li>
											<li class="sub-menu"><a href="/rohini/" data-toggle="tooltip" data-placement="right" title="Dee Pearls Banquets"><div>RPB Rohini Sec-10</div></a></li>
										</ul>
									</li>
									
									
								</ul>
							</li>
							<li><a href="/gallery/"><div>Gallery</div></a>
								
							</li>
							<li><a href="/about-us/"><div>About Us</div></a>
								
							</li>
							<li><a href="/banquets-update/"><div>Blog</div></a>
								
							</li>
							<li class="current"><a href="/contact-us/"><div>Contact Us</div></a>
								
							</li>
							
						</ul>

						
					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header><!-- #header end -->
		
		<!-- Page Title
			============================================= -->
			<section>

				<div class="container clearfix" style="text-align:center;">
					<h1 class="my-h1-tags" style="margin-bottom:0;">Contact Us</h1>
					<h3><span>Get in Touch with Us</span></h3>
					
				</div>

			</section><!-- #page-title end -->
			
			

		
		<section id="content">

			<div class="">

				<div class="container clearfix">
					<h2 class="my-h1-tags">Our Blogs</h2>
					<!-- Posts
					============================================= -->
					<div class="blog-slider clearfix">
						<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-1.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-1.jpg" alt="Standard Post with Image" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Go Underwater</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>If your girl enjoys adventure sports, there’s no better way to win her heart than taking her for scuba diving at Lakshadweep or the Andamans. Underwater proposals can be super fun and absolutely unexpected! Just make sure that your loved one is not struggling underwater and is obviously a trained swimmer.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-2.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-2.jpg" alt="Standard Post with Image" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>On a road trip</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Road trips are romantic and if you can take up the challenge take your loved one to the highest altitude probably in ladakh and pool off your proposal there it will surely leave them into splits. Just Make sure that you check the weather before going down on one knee – you don’t want your moment marred by heavy snowfall or landslide!</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-4.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-4.jpg" alt="Standard Post with Image" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Hot Air Balloon ride in Jaipur</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Fancy a hot-air balloon is something you should try many resorts offer that all you have to do is to book a hot air balloon ride above the resort for extra brownie points and save the question for when you’re cozied up in the air!</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-5.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-5.jpg" alt="Standard Post with Image" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Goa</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Goa tops the list of places for romantic proposals. Imagine yourself as you kneel in the sand with the picture-perfect backdrop of an orange-pink sunset and the sound of waves gently lapping the shore in the background.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-6.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-6.jpg" alt="Standard Post with Image"></a>
								</div>
								<div class="entry-title">
									<h2><a>Amidst in the valley of flowers</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Die-hard romantics are known to give a flower or a bunch of flowers to their girl on every occasion to celebrate. Picture yourself asking her to marry you, while surrounded by the most beautiful flowers at the valley of flowers.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

					</div><!-- blog slider end -->
					<div align="center">
						<a href="http://royalpepperbanquets.com/banquets-update/" target="_blank" class="t400 capitalize button button-light button-circle bottommargin btn-golden"> View All Blog </a>
					</div>
				</div>

			</div>

		</section>
	

		<!-- Form
		============================================= -->
		<section class="slider" class="slider-parallax full-screen">

			<div class="slider-parallax-inner">

				<div class="full-screen dark section nopadding nomargin noborder ohidden" style="background-image: url('../images/page/form-banner.jpg'); background-size: cover; background-position: center center;">

					<div class="row nomargin" style="position: relative; z-index: 2;">
						<div class="col-md-offset-7 col-md-5 full-screen" style="background-color: rgba(0,0,0,0.45);">
							<div class="vertical-middle col-padding">
								<div class="heading-block nobottomborder bottommargin-sm">
									<h2 style="font-size: 22px;">Send us an Email</h2>
									
								</div>
								<form action="" method="post" class="clearfix" style="max-width: 500px;">
									<div class="row">
										<div class="col-sm-6">
											<div class="col_full">
												<label class="capitalize t600">Name:*</label>
												<input type="text" id="template-op-form-name" name="txtname" value="" class="form-control not-dark" placeholder="Name" required="required">
											</div>
											<div class="col_full">
												<label class="capitalize t600">Email:*</label>
												<input type="email" id="template-op-form-email" name="txtmail" value="" class="form-control not-dark" placeholder="Email" required="required">
											</div>
											<div class="col_full">
												<label class="capitalize t600">Phone:*</label>
												<input type="number" id="template-op-form-phone" name="txtphn" value="" class="form-control not-dark" required="required" />
											</div>		
										</div>
										<div class="col-sm-6">
											<div class="col_full">
												<label class="capitalize t600">Date of Function:*</label>
												<input type="date" id="template-op-form-dof" name="txtdof" value="" class="form-control not-dark" required="required" />
											</div>
											<div class="col_full">
												<label class="capitalize t600">Expected Gathering:*</label>
												<select class="form-control not-dark" name="expectgather" required="required">
													<option>--Select--</option>
													<option>0-50</option>
													<option>50-100</option>
													<option>100-150</option>
													<option>150-200</option>
													<option>200-250</option>
													<option>250-300</option>
													<option>300-350</option>
													<option>350-400</option>
													<option>400-450</option>
													<option>450-500</option>
													<option>500+</option>
												</select>
											</div>
											<div class="col_full">
												<label class="capitalize t600">Select our Unit:*</label>
												<select class="form-control not-dark" name="selectunit" required="required">
													<option>--Select--</option>
													<option>Royal Pepper Banquets Wazirpur</option>
													<option>Royal Pepper Banquets Peeragarhi</option>
													<option>Royal Pepper Banquets Rohini Sector-3</option>
													<option>Royal Pepper Banquets Rohini Sector-10</option>
												</select>
											</div>
										</div>
									</div>
									
									
									<div class="col_full">
										
										<textarea id="template-op-form-textarea" name="txtmessage" value="" class="form-control not-dark" rows="5" placeholder="Your Message (Max. 1000 Characters)"></textarea>
									</div>
									<div class="col_full nobottommargin" style="text-align: center;">
										<button type="submit" class="t400 capitalize button button-border button-light button-circle nomargin" name="submitbig"> Submit </button>
									</div>
								</form>
								
							</div>
						</div>
					</div>

					<div class="video-wrap" style="z-index:1;">
						<div class="video-overlay" style="background: rgba(0,0,0,0.2);"></div>
					</div>

				</div>

			</div>

		</section><!-- #slider end -->


		<!-- Footer -->

	<footer id="item-6" class="footer ut-footer-dark" style="background-color: #000; ">        
        <div id="map-parent" class="ut-footer-area lazy" style="width:60%;float:left;padding-left:10%;">
            <div style="top:100px;height:400px;margin:25px;" id="map">
               
                        
                    
            </div>
            
        </div>
		<div id="rpb-fb" style="width:40%;float:right;padding:5% 12% 0%;" class="lazy">
        		<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FRoyalPepperBanquets&tabs=timeline&width=300&height=500&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="300" height="500" style="border:none; overflow:hidden;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
     		</div>        
       
                    
        
        <div class="clear"></div>
                
            <div class="footer-content">        
                    
                <div id="rpb-copy" class="grid-container" style="margin-left:35%; height: 100px;">
                        
                    <div id="rpb-copy1" class="grid-70 prefix-15 mobile-grid-100 tablet-grid-100" style="text-align:center;">
                        
                        <i class="icon-envelope2"></i>
                        <a class="mycolors" href="mailto:info@royalpepperbanquets.com"> info@royalpepperbanquets.com </a>
                        <span class="middot">·</span> 
                        <i class="icon-headphones"></i> 
                        <a class="mycolors" href="tel:+918882500400" target="_blank">+91-8882-500-400 </a>
                        <br>Copyrights © 2016 Royal Pepper Banquets. <span> All Rights Reserved </span>                        
                        <ul class="ut-footer-so">
	                     <li style="display: inline-block;"><a title="facebook" href="https://www.facebook.com/RoyalPepperBanquets/" target="_blank" class="si-facebook social-icon si-small"><i class="icon-facebook"></i><i class="icon-facebook"></i></a></li>
	                        <li style="display: inline-block;"><a title="Twitter" href="https://twitter.com/royal_pepper" target="_blank" class="si-twitter social-icon si-small"><i class="icon-twitter"></i><i class="icon-twitter"></i></a></li>
	                        <li style="display: inline-block;"><a title="LinkedIN" href="https://www.linkedin.com/company-beta/13214770/" target="_blank" class="si-linkedin social-icon si-small"><i class="icon-linkedin "></i><i class="icon-linkedin "></i></a></li>
	                        <li style="display: inline-block;"><a title="Instagram" href="https://www.instagram.com/royalpepperbanquets/" target="_blank" class="si-instagram social-icon si-small"><i class="icon-instagram"></i><i class="icon-instagram"></i></a></li>
                        </ul>                    
                       <div><span>Designed &amp; Developed by: <a href="http://www.wishadesign.com/" target="_blank">WAD</a></span></div>
                                
                    </div>
                            
                </div><!-- close container -->        
            </div><!-- close footer content -->
                
    </footer>

    </div>
   <div class="contact-form">
	    <form action="" method="post" style="margin:0;">
	    		<h4 style="background: #dfa700;color: #fff;margin:0;text-align: center;padding: 0 5px;cursor: pointer;">May I Help You? <span class="closing hiding" style="float: right;width: 25px;color:#fff;">&times</span></h4>
	    	<div class="hiding" id="contact-inner-div" align="center">
	    		
	    		<input class="form-control" type="text" name="txtname" placeholder="Your Name..."><br>
	    		
	    		<input class="form-control" type="number" name="txtphn" placeholder="Your Number..."><br>
	    		
	    		<input class="form-control" type="email" name="txtmail" placeholder="Your Email ID..."><br>
	    		
	    		<textarea class="form-control" rows="2" placeholder="Your Message (Max. 1000 Characters)..." name="txtmessage"></textarea><br>
	    		<input type="submit" name="submitsmall" value="Submit" class="form-control">
	    	</div>
	   		 
	    </form>
    </div>
    <div id="gotoTop" class="icon-angle-up"></div>
		
		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/plugins.js"></script>
	<script src="../js/bootstrap.min.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="../js/functions.js"></script>

	<!-- SLIDER REVOLUTION 5.x SCRIPTS  -->
	<script type="text/javascript" src="../include/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
	<script type="text/javascript" src="../js/jquery.lazy.min.js"></script>
	<script type="text/javascript" src="../js/slick.js"></script>


	<script>
		jQuery(document).ready(function($){
		var t=setTimeout(function(){
			$(window).trigger('load');
			// if(SEMICOLON.isMobile.any()){
			// 	$(window).trigger('load');
			// }
		},2500);
	});
	
		$(document).ready(function(){
		$.each( $('*'), function() { 
			
			if( $(this).width() > $('body').width()) {
				var b_width=$('body').width();
				$(this).css({width : b_width});
				
			} 
		});
	});
		/* Lazy Loading */
	$(document).ready(function(){
		$(function() {
	        $('.lazy').Lazy({
		        // your configuration goes here
		        scrollDirection: 'vertical',
		        effect: 'fadeIn',
		        visibleOnly: true,
		        onError: function(element) {
		            console.log('error loading ');
		        }
		    });
   	 	});
	});

		$(document).ready(function(){
			setTimeout(function(){
        	$(".closing").removeClass("hiding");
			$("#contact-inner-div").removeClass("hiding");
			$("#contact-inner-div").css("background","#fff");
			$("#contact-inner-div label").css("color","#dfa700");
    	},8000);
		 
		$(".contact-form").click(function(){
			
			$(".closing").removeClass("hiding");
			$("#contact-inner-div").removeClass("hiding");
			$("#contact-inner-div").css("background","#fff");
			$("#contact-inner-div label").css("color","#dfa700");
		});
		var myclose=$('.contact-form')[0].children[0].children[0].children[0];
		$(myclose).on("mousedown",function(){
			$(".closing").addClass("hiding");
			$("#contact-inner-div").addClass("hiding");
		});
	});
	</script>

	<script>
		$('.blog-slider').slick({
	      //dots: true,
	      infinite: true,
	      centerMode: false,
	      arrows: false,
	      pauseOnFocus: false,
	      centerPadding: '0%',
	      slidesToShow: 3,
	      speed: 500,
	      autoplay: true,
	      autoplaySpeed: 1500,
	      // responsive: [{

	      //       breakpoint: 992,
	      //       settings: {
	      //         slidesToShow: 1
	      //       }

	      //     }]
	      responsive: [
	        {
	          breakpoint: 1024,
	          settings: {
	            slidesToShow: 3
	          }
	        },
	        {
	          breakpoint: 780,
	          settings: {
	            slidesToShow: 2
	          }
	        },
	        {
	          breakpoint: 600,
	          settings: {
	            slidesToShow: 1
	          }
	        }

	      ]
	    });

	</script>


	<script>

			/*Maps*/

      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: {lat: 28.7, lng: 77.145},
		  styles: [
    {
        "featureType": "all",
        "elementType": "labels.text.fill",
        "stylers": [
            {
                "saturation": 36
            },
            {
                "color": "#333333"
            },
            {
                "lightness": 40
            }
        ]
    },
    {
        "featureType": "all",
        "elementType": "labels.text.stroke",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "color": "#ffffff"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "all",
        "elementType": "labels.icon",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#fefefe"
            },
            {
                "lightness": 17
            },
            {
                "weight": 1.2
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f7f2ed"
            },
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "landscape.natural.landcover",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#000000"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f5f5f5"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#dedede"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 17
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 29
            },
            {
                "weight": 0.2
            }
        ]
    },
    {
        "featureType": "road.arterial",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 18
            }
        ]
    },
    {
        "featureType": "road.local",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "transit",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f2f2f2"
            },
            {
                "lightness": 19
            }
        ]
    },
    {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#cbf2f2"
            }
        ]
    }
]
        });

        setMarkers(map);
      }

      
      var rpb = [
       	['Wazirpur', 28.704734,77.172242, 4],
		['Rohini Sec-3', 28.703657,77.108054, 3],
		['Peeragarhi', 28.708136,77.124667, 2],
		['Rohini Sec-10', 28.706755,77.105493, 1]
      ];

      function setMarkers(map) {
       
        for (var i = 0; i < rpb.length; i++) {
          var myunits = rpb[i];
          var marker = new google.maps.Marker({
            position: {lat: myunits[1], lng: myunits[2]},
            map: map,
			icon: '../images/11.png',
			html:	myunits[0],
            title: myunits[0],
            zIndex: myunits[3]
          });
        }
      }
    </script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAJX5xXhBvqGPED4CMcoTGmGCTcqX99JH4&callback=initMap">
    </script>
			
</body>
</html>