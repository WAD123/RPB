<!DOCTYPE html>
<html lang="en">
<head>
	<?php
		if(isset($_POST['submitbig'])){
			$name=$_REQUEST['txtname'];
			$phn=$_REQUEST['txtphn'];
			$email=$_REQUEST['txtmail'];
			$dof=$_REQUEST['txtdof'];
			$gather=$_REQUEST['expectgather'];
			$unit=$_REQUEST['selectunit'];
			$msg=$_REQUEST['txtmessage'];

			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Feedback";
			$txt = "Customer Name: ".$name."."."\r\n"."Customer Phone Number: ".$phn."."."\r\n"."Date of function: ".$dof."."."\r\n"."Expected Gathering: ".$gather."."."\r\n"."Unit: ".$unit."."."\r\n"."Customer Message: ".$msg;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);
				
			$link=mysqli_connect("localhost","root","wad@root123","royal_pepper");

			if (!$link) {
				 ?>
			   <script>alert("Connection Failed. There is some problem.");</script>
			    <?php
			    
			}

			$sql = "INSERT INTO contactform_big(Cust_Name,Email,Phone,Date_Of_Function,Expect_Gather,Unit,Message) VALUES ('".$name."','".$email."','".$phn."','".$dof."','".$gather."','".$unit."','".$msg."')";

			if (mysqli_query($link, $sql)) {
					  ?>
	    			    <script>alert("Your details have been submitted. We will get back to you soon.");</script>
	   				 <?php
	   				 

			} else {
			    ?>
			   <script>alert("There is some problem.");</script>
			    <?php
			   
			}

			mysqli_close($link);
		}
		
		if(isset($_POST['submitsmall'])){
			$name=$_REQUEST['txtname'];
			$phn=$_REQUEST['txtphn'];
			$email=$_REQUEST['txtmail'];
			$msg=$_REQUEST['txtmessage'];
			
			$to = "royalpepperbanquets@gmail.com";
			$subject = "RPB Feedback";
			$txt = "Customer Name: ".$name."."."\r\n"."Customer Phone Number: ".$phn."."."\r\n"."Customer Message: ".$msg;
			$headers =  "From: ".$email. "\r\n"."CC: info@royalpepperbanquets.com";

			mail($to,$subject,$txt,$headers);

				$link1=mysqli_connect("localhost","root","wad@root123","royal_pepper");

				if (!$link1) {
				 ?>
			   <script>alert("Connection Failed. There is some problem.");</script>
			    <?php
			    
			}

			$sql = "INSERT INTO contactform_small(Cust_Name,Phone,Email,Message) VALUES ('".$name."','".$phn."','".$email."','".$msg."')";

			if (mysqli_query($link1, $sql)) {
				  ?>
	    			    <script>alert("Your details have been submitted. We will get back to you soon.");</script>
	   			 <?php
	   			
				
			} else {
				 ?>
			   <script>alert("There is some problem.");</script>
			    <?php
			   
			}

			mysqli_close($link1);

		}
	?>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta http-equiv="content-type" content="text/html">
	<meta name="description" content=" Royal Pepper Banquets is a renowned Best Banquet Halls in Peeragarhi, providing luxury Marriage Hall for wedding and corporate events with unforgettable experience at reasonable prices.">
	<meta name="keywords" content=" best banquet in peeragarhi, wedding halls in peeragarhi, marriage halls in peeragarhi, luxurious banquets in peeragarhi, top wedding halls in peeragarhi, luxury wedding in peeragarhi, top marriage halls in peeragarhi, top banquets hall in peeragarhi, best marriage halls in peeragarhi, best banquets hall in peeragarhi, best wedding halls in peeragarhi.">
	<!-- Stylesheets
	============================================= -->
	
	
	<!-- MY CSS -->
	<link rel="stylesheet" href="../css/mystyle.css" type="text/css" />
	<link rel="stylesheet" href="../css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="../css/style.css" type="text/css" />
	<link rel="stylesheet" href="../css/main.css" type="text/css">
	<!-- One Page Module Specific Stylesheet -->
	<link rel="stylesheet" href="../css/onepage.css" type="text/css" />
    <link rel="canonical" href="http://www.royalpepperbanquets.com/peeragarhi/" />
	<link rel="stylesheet" href="../css/dark.css" type="text/css" />
	<link rel="stylesheet" href="../css/font-icons.css" type="text/css" />
	<link rel="stylesheet" href="../css/et-line.css" type="text/css" />
	<link rel="stylesheet" href="../css/animate.css" type="text/css" />
	<link rel="stylesheet" href="../css/magnific-popup.css" type="text/css" />
	<link rel="stylesheet" href="../css/fonts.css" type="text/css" />
	<link rel="stylesheet" href="../css/responsive.css" type="text/css" />
	
	<!--[if lt IE 9]>
		<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
	<![endif]-->

	<!-- SLIDER REVOLUTION 5.x CSS SETTINGS -->
	<link rel="stylesheet" type="text/css" href="../include/rs-plugin/css/settings.css" media="screen" />
	<link rel="stylesheet" type="text/css" href="../include/rs-plugin/css/layers.css">
	<link rel="stylesheet" type="text/css" href="../include/rs-plugin/css/navigation.css">
	
	
	<link rel="icon" href="../include/rs-plugin/demos/assets/images/rpb.png">

</head>

	<!-- Document Title
	============================================= -->
	<title>Best Banquet Halls In Peeragarhi Marriage Wedding Hall In Peeragarhi | Royal Pepper Banquets </title>

	
	<link id="swcolors-Css" rel="stylesheet" href="../css/colors.css" type="text/css">

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106006908-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-106006908-1');
</script>

<!-- Google Code for Remarketing Tag -->
<!--------------------------------------------------
Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup
--------------------------------------------------->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 822487020;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/822487020/?guid=ON&amp;script=0"/>
</div>
</noscript>


</head>

<body class="stretched" style="overflow-x:hidden;" data-loader="4">
	<!-- Google Tag Manager (noscript) -->
	<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-PPJWK7G"
	height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
	<!-- End Google Tag Manager (noscript) -->


	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

		<!-- Header
		============================================= -->
		<header id="header" class="full-header" data-sticky-class="not-dark">

			<div id="header-wrap">

				<div class="container clearfix">

					<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="http://www.royalpepperbanquets.com" class="standard-logo"><img src="../images/logo.png" alt="Royal Pepper Banquets"></a>
						<a href="http://www.royalpepperbanquets.com" class="retina-logo"><img src="../images/logo.png" alt="Royal Pepper Banquets"></a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu">

						<ul>
							<li><a href="http://www.royalpepperbanquets.com"><div>Home</div></a>
								
							</li>
							<li class="current"><a href="http://www.royalpepperbanquets.com/#units"><div>Our Units</div></a>
								<ul>
									<li class="current sub-menu"><a href="/peeragarhi/" data-toggle="tooltip" data-placement="right" title="Place of Dreams Banquets"><div> Peeragarhi</div></a>
										
									
										
									</li>
									<li class="sub-menu"><a href="/wazirpur/"><div>Wazirpur </div></a>
										
									</li>
									<li class="sub-menu"><a href="/rohini/"><div>Rohini</div></a>
										<ul>
											<li class="sub-menu"><a href="/rohini/"><div>Rohini Sec-3</div></a></li>
											<li class="sub-menu"><a href="/rohini/" data-toggle="tooltip" data-placement="right" title="Dee Pearls Banquets"><div>Rohini Sec-10</div></a></li>
										</ul>
									</li>
									
									
								</ul>
							</li>
							<li><a href="/gallery/"><div>Gallery</div></a>
								
							</li>
							<li><a href="/about-us/"><div>About Us</div></a>
								
							</li>
							<li><a href="/banquets-update/"><div>Blog</div></a>
								
							</li>
							<li><a href="/contact-us/"><div>Contact Us</div></a>
								
							</li>
							
						</ul>

						
					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header><!-- #header end -->

		<section>

			<div style="height:89vh">
				
			<iframe src="https://www.google.com/maps/embed?pb=!1m0!4v1510737260434!6m8!1m7!1sCAoSLEFGMVFpcE5nM1NjamlGaXRtNnphVW9LNmgweGpMREowU0xoRFVYN250c05r!2m2!1d28.68011308867027!2d77.09367120699335!3f103!4f0!5f0.7820865974627469" width="100%" height="100%" frameborder="0" style="border:0" allowfullscreen></iframe>	
							<!-- MAIN IMAGE -->
							<!-- <img id="banner-img2" src="../include/rs-plugin/demos/assets/images/peeragarhi.jpg" data-bgfit="cover" data-animate="swing" data-delay="200" alt="banquets in Peeragarhi, Banquet hall in peeragarhi, place of dreams by Royal Pepper Banquets"> -->
							<!-- LAYERS -->
					
				
			</div>
		</section>
		<section class="about">
		
		<div><h1 align="center" style="color:#555555;">Wedding Marriage Parties In Top Banquet Halls Peeragarhi</h1>
					<p class="lead" style="text-align: justify;"><small>We work with absolute charm and devotion for all sorts of events like Pre and post Wedding Ceremonies (Sagan, Vedi etc), Mata ki Chowki, Theatre, Birthday party, and many more. We assure to create a charismatic aura and lead you to the gateway of heaven and bliss for that is what we work for. The central location is very easily accessible leading your guests to the venue without much trouble. Our catering amenity includes the excellent performance of our trained chefs giving your beloved guests the access to a wide variety of vegetarian cuisines.</small></p>
					<br /><p class="lead" align="center"><b>We Promise</b></p>
					<hr style="width:100px;border:2px dashed;text-align: center;margin-bottom: 50px;">
					<p class="lead"><small>
					• Supreme hospitality<br />• Fully furnished banquet hall<br />• Graceful interiors<br />• Delicious Indian cuisines and others as well<br />• Free valet parking<br />• Fully equipped modern kitchen chefs<br />• Capacity to accommodate 800 people and more.</small> 
					</p>
					<p class="lead" style="text-align: justify;"><small>You can simply contact us to have a blissful and royal experience for every event you wish to organize. Leave all your tensions just by reserving a banquet hall in advance so that we can have enough time to come out with the best. We are in touch with all the talented designers who are well acquainted with the latest trends in the designing world.</small></p>
						<br /><p class="lead" align="center"><b>You can contact us for having:</b></p>
					<hr style="width:100px;border:2px dashed;text-align: center;margin-bottom: 50px;">
					<p class="lead"><small>
					• Kitty parties<br />•	Lunches<br />•	Birthday parties<br />• Silver and golden jubilee<br />• Retirement parties<br />• Pre and post wedding ceremonies<br />• Corporate meetings customize arrangements to captivate your guest.</small>
					</p>
					<p class="lead" style="text-align: justify;"><small>Banquet halls have the feeling of reputation attached to it, and what is wrong in having one if you can get everything at an extremely affordable price. We are determined to leave an ever lasting impact   on your guests adding further to make it an unforgettable experience for them all. You can also have a look at other units in Rohini and Wazirpur. We are sure to make it convenient for you in every way possible.</small>
					</p>
					
					</div>
		</section>
		<!-- Image Gallery -->
		

		<section style="margin-bottom: 0px;">

			<div>
				<h2 class="my-h1-tags mb-2" data-animate="fadeIn" data-delay="400">Our Gallery</h2>


				<div class="container clearfix">

					<!-- Portfolio Filter
					============================================= -->
					<ul class="portfolio-filter style-4 clearfix" data-container="#portfolio"  data-animate="fadeIn" data-delay="600">

						<li class="activeFilter"><a href="#" data-filter="*">All</a></li>
						<li class=""><a href="#" data-filter=".pf-entrance">Entrance</a></li>
						<li class=""><a href="#" data-filter=".pf-birthday">Birthday</a></li>
						<li class=""><a href="#" data-filter=".pf-mkc">Mata Ki Chowki</a></li>
						<li class=""><a href="#" data-filter=".pf-sagan">Sagan</a></li>
						<li class=""><a href="#" data-filter=".pf-theater">Theater</a></li>
						<li class=""><a href="#" data-filter=".pf-vedi">Vedi</a></li>
						<li class=""><a href="#" data-filter=".pf-others">Others</a></li>

					</ul><!-- #portfolio-filter end -->

					<!-- <div class="portfolio-shuffle" data-container="#portfolio">
						<i class="icon-random"></i>
					</div> -->

					<div class="clear"></div>

					<!-- Portfolio Items
					============================================= -->
					<div id="portfolio" class="portfolio grid-container grid-container clearfix" style="position: relative; height: 888px;">

						<!-- <article class="portfolio-item pf-media pf-icons" style="position: absolute">
							<div class="">
								
									<img src="images/peeragarhi/birthday/b1.jpg">
								
							</div>
						</article> -->

						<article class="portfolio-item pf-entrance" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/entrance/e1.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/entrance/e1.jpg">	
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-entrance" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/entrance/e4.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/entrance/e4.jpg">	
								</a>			
								
							</div>
						</article>

						<article class="portfolio-item pf-entrance" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/entrance/e7.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/entrance/e7.jpg">	
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-entrance" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/entrance/e9.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/entrance/e9.jpg">	
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-entrance" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/entrance/e11.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/entrance/e11.jpg">	
									</a>			
								
							</div>
						</article>

						<article class="portfolio-item pf-entrance" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/entrance/e12.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/entrance/e12.jpg">	
									</a>			
								
							</div>
						</article>

						<article class="portfolio-item pf-entrance" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/entrance/e13.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/entrance/e13.jpg">	
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-entrance" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/entrance/e15.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/entrance/e15.jpg">	
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b1.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b1.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b2.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b2.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b3.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b3.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b4.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b4.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b5.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b5.jpg">
									</a> 
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b6.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b6.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b7.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b7.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b8.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b8.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-birthday" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/birthday/b9.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/birthday/b9.jpg">
									</a>
								
							</div>
						</article>
						
						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m3.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m3.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m4.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m4.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m5.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m5.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m6.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m6.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m7.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m7.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m12.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m12.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m14.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m14.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m16.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m16.jpg">
								</a>		
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m18.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m18.jpg">
								</a>		
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m20.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m20.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m25.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m25.jpg">
								</a>		
								
							</div>
						</article>

						<article class="portfolio-item pf-mkc" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/mata ki chowki/m27.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/mata ki chowki/m27.jpg">
								</a>	
								
							</div>
						</article>	


						<article class="portfolio-item pf-sagan" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/sagan/s2.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/sagan/s2.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-sagan" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/sagan/s4.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/sagan/s4.jpg">
								</a>	
								
							</div>
						</article>

						<article class="portfolio-item pf-sagan" style="position: absolute">
							<div class="">
								
									<a class="myGallery" href="../images/peeragarhi/sagan/s5.jpg" data-lightbox="image">
										<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/sagan/s5.jpg">
									</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-sagan" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/sagan/s6.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/sagan/s6.jpg">
								</a>	
								
							</div>
						</article>

						
						<article class="portfolio-item pf-theater" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/theater/t1.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/theater/t1.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-theater" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/theater/t2.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/theater/t2.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-vedi" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/vedi/v1.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/vedi/v1.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-vedi" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/vedi/v2.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/vedi/v2.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-vedi" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/vedi/v3.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/vedi/v3.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g2.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g2.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g4.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g4.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g6.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g6.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g7.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g7.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g8.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g8.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g9.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g9.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g10.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g10.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g18.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g18.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g19.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g19.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g20.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g20.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g21.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g21.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g22.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g22.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g23.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g23.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g24.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g24.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g26.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g26.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g29.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g29.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g31.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g31.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g33.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g33.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g34.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g34.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g35.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g35.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g37.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g37.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g40.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g40.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g44.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g44.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g45.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g45.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g46.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g46.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g48.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g48.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g49.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g49.jpg">
								</a>
								
							</div>
						</article>

						<article class="portfolio-item pf-others" style="position: absolute">
							<div class="">
								
								<a class="myGallery" href="../images/peeragarhi/gallery/g50.jpg" data-lightbox="image">
									<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g50.jpg">
								</a>
								
							</div>
						</article>



						

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g3.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g3.jpg">
							</a> -->

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g5.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g5.jpg">
							</a> -->

							

							

							

							

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g11.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g11.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g12.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g12.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g13.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g13.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g14.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g14.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g15.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g15.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g16.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g16.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g17.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g17.jpg">
							</a> -->

							

							

							

							

							

							

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g25.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g25.jpg">
							</a> -->

							

						<!-- 	<a class="myGallery" href="../images/peeragarhi/gallery/g27.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g27.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g28.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g28.jpg">
							</a> -->

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g30.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g30.jpg">
							</a> -->

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g32.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g32.jpg">
							</a> -->

							

							

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g36.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g36.jpg">
							</a> -->

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g38.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g38.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g39.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g39.jpg">
							</a> -->

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g41.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g41.jpg">
							</a>

							<a class="myGallery" href="../images/peeragarhi/gallery/g42.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g42.jpg">
							</a> -->

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g43.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g43.jpg">
							</a> -->

							

							

							

							<!-- <a class="myGallery" href="../images/peeragarhi/gallery/g47.jpg" target="_blank">
								<img class="myzoom  img-thumbnail" alt="" src="../images/peeragarhi/gallery/g47.jpg">
							</a> -->

							

							

							


					</div><!-- #portfolio end -->

				</div>

			</div>

		</section>

		<!-- Menu -->
		
		<section id="menu">
	        <div class="container">
				
				<h2 class="my-h1-tags">Peeragarhi Banquet Menu</h2>

				<!-- Menu slider -->
				<div>
					<div id="carousel-slider" class="carousel slide" data-ride="carousel">
						<!-- Indicators -->
					  	<ol class="carousel-indicators visible-xs">
						    <li data-target="#carousel-slider" data-slide-to="0" class="active"></li>
						    <li data-target="#carousel-slider" data-slide-to="1"></li>
						    <li data-target="#carousel-slider" data-slide-to="2"></li>
						     <li data-target="#carousel-slider" data-slide-to="3"></li>
						    <li data-target="#carousel-slider" data-slide-to="4"></li>
						    <li data-target="#carousel-slider" data-slide-to="5"></li>
						    <li data-target="#carousel-slider" data-slide-to="6"></li>
						    <li data-target="#carousel-slider" data-slide-to="7"></li>
					  	</ol>

						<div class="carousel-inner">
							<div class="item active" align="center">
								<img src="../images/peeragarhi menu/index.jpg" class="img-responsive" alt=""> 
						   </div>
						   <div class="item" align="center">
								<img src="../images/peeragarhi menu/menu1.jpg" class="img-responsive" alt=""> 
						   </div> 
						   <div class="item" align="center">
								<img src="../images/peeragarhi menu/menu2.jpg" class="img-responsive" alt=""> 
						   </div> 
						   <div class="item" align="center">
								<img src="../images/peeragarhi menu/menu3.jpg" class="img-responsive" alt=""> 
						   </div>
						   <div class="item" align="center">
								<img src="../images/peeragarhi menu/menu4.jpg" class="img-responsive" alt=""> 
						   </div>
						   <div class="item" align="center">
								<img src="../images/peeragarhi menu/menu5.jpg" class="img-responsive" alt=""> 
						   </div>
						   <div class="item" align="center">
								<img src="../images/peeragarhi menu/menu6.jpg" class="img-responsive" alt=""> 
						   </div>
						   <div class="item" align="center">
								<img src="../images/peeragarhi menu/menu7.jpg" class="img-responsive" alt=""> 
						   </div>
						</div>
						
						
						<a class="left carousel-control hidden-xs" href="#carousel-slider" data-slide="prev">
							<i class="icon-angle-left"></i> 
						</a>
						
						<a class="right carousel-control hidden-xs" href="#carousel-slider" data-slide="next">
							<i class="icon-angle-right"></i> 
						</a>
					</div> <!--/#carousel-slider-->
				</div><!--/#about-slider-->
			</div><!--/.container-->
	    </section><!--/about-us-->

	    <section>
	    	<div class="container clearfix">
					<h2 class="my-h1-tags">Downloads</h2>

	    		<div align="center">
					<a href="../include/assets/peeragarhi.pdf" class="t400 capitalize button button-light button-circle bottommargin btn-golden" download>Peeragarhi Location Map </a>
					<!-- <a href="../include/assets/the maiden crown.pdf" class="t400 capitalize button button-light button-circle bottommargin btn-golden" download>The Maiden Crown Location Map </a> -->
				</div>
	    	</div>
	    </section>
	
	
		
		<section id="content">

			<div class="">

				<div class="container clearfix">
					<h2 class="my-h1-tags">Our Blogs</h2>
					<!-- Posts
					============================================= -->
					<div class="blog-slider clearfix">
						<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-1.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-1.jpg" alt="Standard Post with Image" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Go Underwater</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>If your girl enjoys adventure sports, there’s no better way to win her heart than taking her for scuba diving at Lakshadweep or the Andamans. Underwater proposals can be super fun and absolutely unexpected! Just make sure that your loved one is not struggling underwater and is obviously a trained swimmer.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-2.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/05/blog-33-2.jpg" alt="Standard Post with Image" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>On a road trip</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Road trips are romantic and if you can take up the challenge take your loved one to the highest altitude probably in ladakh and pool off your proposal there it will surely leave them into splits. Just Make sure that you check the weather before going down on one knee – you don’t want your moment marred by heavy snowfall or landslide!</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-4.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-4.jpg" alt="Standard Post with Image" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Hot Air Balloon ride in Jaipur</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Fancy a hot-air balloon is something you should try many resorts offer that all you have to do is to book a hot air balloon ride above the resort for extra brownie points and save the question for when you’re cozied up in the air!</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-5.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-5.jpg" alt="Standard Post with Image" style="opacity: 1;"></a>
								</div>
								<div class="entry-title">
									<h2><a>Goa</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Goa tops the list of places for romantic proposals. Imagine yourself as you kneel in the sand with the picture-perfect backdrop of an orange-pink sunset and the sound of waves gently lapping the shore in the background.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

							<div class="entry clearfix">
								<div class="entry-image">
									<a href="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-6.jpg" data-lightbox="image"><img class="image_fade" src="http://www.royalpepperbanquets.com/banquets-update/wp-content/uploads/2017/06/blog-33-6.jpg" alt="Standard Post with Image"></a>
								</div>
								<div class="entry-title">
									<h2><a>Amidst in the valley of flowers</a></h2>
								</div>
								<ul class="entry-meta clearfix">
									<!-- <li><i class="icon-calendar3"></i> 10th Feb 2014</li> -->
									<!-- <li><a href="blog-single.html#comments"><i class="icon-comments"></i> 13</a></li> -->
									<!-- <li><a href="#"><i class="icon-camera-retro"></i></a></li> -->
								</ul>
								<div class="entry-content">
									<p>Die-hard romantics are known to give a flower or a bunch of flowers to their girl on every occasion to celebrate. Picture yourself asking her to marry you, while surrounded by the most beautiful flowers at the valley of flowers.</p>
									<!-- <a href="blog-single.html" class="more-link">Read More</a> -->
								</div>
							</div>

					</div><!-- blog slider end -->
					<div align="center">
						<a href="http://royalpepperbanquets.com/banquets-update/" target="_blank" class="t400 capitalize button button-light button-circle bottommargin btn-golden"> View All Blog </a>
					</div>
				</div>

			</div>

		</section>

		<!-- Form
		============================================= -->
		<section class="slider" class="slider-parallax full-screen">

			<div class="slider-parallax-inner lazy">

				<div class="full-screen dark section nopadding nomargin noborder ohidden" style="background-image: url('../images/page/form-banner.jpg'); background-size: cover; background-position: center center;">

					<div class="row nomargin" style="position: relative; z-index: 2;">
						<div class="col-md-offset-7 col-md-5 full-screen" style="background-color: rgba(0,0,0,0.45);">
							<div class="vertical-middle col-padding">
								<div class="heading-block nobottomborder bottommargin-sm">
									<h2 style="font-size: 22px;">Send Us An Email</h3>
									
								</div>
								<form action="" method="post" class="clearfix" style="max-width: 500px;">
									<div class="row">
										<div class="col-sm-6">
											<div class="col_full">
												<label class="capitalize t600">Name:*</label>
												<input type="text" id="template-op-form-name" name="txtname" value="" class="form-control not-dark" placeholder="Name" required="required">
											</div>
											<div class="col_full">
												<label class="capitalize t600">Email:*</label>
												<input type="email" id="template-op-form-email" name="txtmail" value="" class="form-control not-dark" placeholder="Email" required="required">
											</div>
											<div class="col_full">
												<label class="capitalize t600">Phone:*</label>
												<input type="number" id="template-op-form-phone" name="txtphn" value="" class="form-control not-dark" required="required" />
											</div>		
										</div>
										<div class="col-sm-6">
											<div class="col_full">
												<label class="capitalize t600">Date of Function:*</label>
												<input type="date" id="template-op-form-dof" name="txtdof" value="" class="form-control not-dark" required="required" />
											</div>
											<div class="col_full">
												<label class="capitalize t600">Expected Gathering:*</label>
												<select class="form-control not-dark" name="expectgather" required="required">
													<option>--Select--</option>
													<option>0-50</option>
													<option>50-100</option>
													<option>100-150</option>
													<option>150-200</option>
													<option>200-250</option>
													<option>250-300</option>
													<option>300-350</option>
													<option>350-400</option>
													<option>400-450</option>
													<option>450-500</option>
													<option>500+</option>
												</select>
											</div>
											<div class="col_full">
												<label class="capitalize t600">Select our Unit:*</label>
												<select class="form-control not-dark" name="selectunit" required="required">
													<option>--Select--</option>
													<option>Royal Pepper Banquets Wazirpur</option>
													<option>Royal Pepper Banquets Peeragarhi</option>
													<option>Royal Pepper Banquets Rohini Sector-3</option>
													<option>Royal Pepper Banquets Rohini Sector-10</option>
												</select>
											</div>
										</div>
									</div>
									
									
									<div class="col_full">
										
										<textarea id="template-op-form-textarea" name="txtmessage" value="" class="form-control not-dark" rows="5" placeholder="Your Message (Max. 1000 Characters)"></textarea>
									</div>
									<div class="col_full nobottommargin" style="text-align: center;">
										<button type="submit" class="t400 capitalize button button-border button-light button-circle nomargin" name="submitbig"> Submit </button>
									</div>
								</form>
								
							</div>
						</div>
					</div>

					<div class="video-wrap" style="z-index:1;">
						<div class="video-overlay" style="background: rgba(0,0,0,0.2);"></div>
					</div>

				</div>

			</div>

		</section><!-- #slider end -->


		<!-- Footer -->

		<footer id="item-6" class="footer ut-footer-dark" style="background-color: #000; ">        
        <div id="map-parent" class="ut-footer-area lazy" style="width:60%;float:left;padding-left:10%;">
            <div style="top:100px;height:400px;margin:25px;" id="map">
               
                        
                    
            </div>
            
        </div>
		<div id="rpb-fb" style="width:40%;float:right;padding:5% 12% 0%;" class="lazy">
        		<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FRoyalPepperBanquets&tabs=timeline&width=300&height=500&small_header=true&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="300" height="500" style="border:none; overflow:hidden;" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
     		</div>        
       
                    
        
        <div class="clear"></div>
                
            <div class="footer-content">        
                    
                <div id="rpb-copy" class="grid-container" style="margin-left:35%; height: 100px;">
                        
                    <div id="rpb-copy1" class="grid-70 prefix-15 mobile-grid-100 tablet-grid-100" style="text-align:center;">
                        
                        <i class="icon-envelope2"></i>
                        <a class="mycolors" href="mailto:info@royalpepperbanquets.com"> info@royalpepperbanquets.com </a>
                        <span class="middot">·</span> 
                        <i class="icon-headphones"></i> 
                        <a class="mycolors" href="tel:+918882500400" target="_blank">+91-8882-500-400 </a>
                        <br>Copyrights © 2017 <strong>Royal Pepper Banquets</strong>. <span> All Rights Reserved </span>                        
                        <ul class="ut-footer-so">
	                      <li style="display: inline-block;"><a title="facebook" href="https://www.facebook.com/RoyalPepperBanquets/" target="_blank" class="si-facebook social-icon si-small"><i class="icon-facebook"></i><i class="icon-facebook"></i></a></li>
	                        <li style="display: inline-block;"><a title="Twitter" href="https://twitter.com/royal_pepper" target="_blank" class="si-twitter social-icon si-small"><i class="icon-twitter"></i><i class="icon-twitter"></i></a></li>
	                        <li style="display: inline-block;"><a title="LinkedIN" href="https://www.linkedin.com/company-beta/13214770/" target="_blank" class="si-linkedin social-icon si-small"><i class="icon-linkedin "></i><i class="icon-linkedin "></i></a></li>
	                        <li style="display: inline-block;"><a title="Instagram" href="https://www.instagram.com/royalpepperbanquets/" target="_blank" class="si-instagram social-icon si-small"><i class="icon-instagram"></i><i class="icon-instagram"></i></a></li>
                        </ul>                    
                       <div><span>Designed &amp; Developed by: <a href="http://www.wishadesign.com/" target="_blank">WAD</a></span></div>
                                
                    </div>
                            
                </div><!-- close container -->        
            </div><!-- close footer content -->
                
    </footer>

	</div>
	<div class="contact-form">
	    <form action="" method="post" style="margin:0;">
	    		<h4 style="background: #dfa700;color: #fff;margin:0;text-align: center;padding: 0 5px;cursor: pointer;">May I Help You? <span class="closing hiding" style="float: right;color: #fff;width:25px;">&times</span></h4>
	    	<div class="hiding" id="contact-inner-div" align="center">
	    		
	    		<input class="form-control" type="text" name="txtname" placeholder="Your Name..."><br>
	    		
	    		<input class="form-control" type="number" name="txtphn" placeholder="Your Number..."><br>
	    		
	    		<input class="form-control" type="email" name="txtmail" placeholder="Your Email ID..."><br>
	    		
	    		<textarea class="form-control" rows="2" placeholder="Your Message (Max. 1000 Characters)..." name="txtmessage"></textarea><br>
	    		<input type="submit" name="submitsmall" value="Submit" class="form-control">
	    	</div>
	   		 
	    </form>
    </div>
    
    <div id="gotoTop" class="icon-angle-up"></div>
		
		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/plugins.js"></script>
	<script src="../js/bootstrap.min.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="../js/functions.js"></script>

	<!-- SLIDER REVOLUTION 5.x SCRIPTS  -->
	<script type="text/javascript" src="../include/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>

	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.video.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.slideanims.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.layeranimation.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.navigation.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.parallax.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.carousel.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.actions.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.migration.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/extensions/revolution.extension.kenburn.min.js"></script>
	<script type="text/javascript" src="../include/rs-plugin/js/addons/revolution.addon.polyfold.min.js"></script>
	<script type="text/javascript" src="../js/jquery.lazy.min.js"></script>
	<script type="text/javascript" src="../js/slick.js"></script>


	<script type="text/javascript">
	jQuery(document).ready(function($){
		var t=setTimeout(function(){
			$(window).trigger('load');
			// if(SEMICOLON.isMobile.any()){
			// 	$(window).trigger('load');
			// }
		},4000);
	});
	
		$(document).ready(function(){
		$.each( $('*'), function() { 
			
			if( $(this).width() > $('body').width()) {
				var b_width=$('body').width();
				$(this).css({width : b_width});
				
			} 
		});
	});

		/* Lazy Loading */
	$(document).ready(function(){
		$(function() {
	        $('.lazy').Lazy({
		        // your configuration goes here
		        scrollDirection: 'vertical',
		        effect: 'fadeIn',
		        visibleOnly: true,
		        onError: function(element) {
		            console.log('error loading ');
		        }
		    });
   	 	});
	});

		$(document).ready(function(){
			setTimeout(function(){
        	$(".closing").removeClass("hiding");
			$("#contact-inner-div").removeClass("hiding");
			$("#contact-inner-div").css("background","#fff");
			$("#contact-inner-div label").css("color","#dfa700");
    	},8000);
		 
		$(".contact-form").click(function(){
			
			$(".closing").removeClass("hiding");
			$("#contact-inner-div").removeClass("hiding");
			$("#contact-inner-div").css("background","#fff");
			$("#contact-inner-div label").css("color","#dfa700");
		});
		var myclose=$('.contact-form')[0].children[0].children[0].children[0];
		$(myclose).on("mousedown",function(){
			$(".closing").addClass("hiding");
			$("#contact-inner-div").addClass("hiding");
		});
	});

	/*Banners*/
	$(document).ready(function(){
		if($(window).width()<=500){
			
			
			$("#banner-img2").attr("src","../include/rs-plugin/demos/assets/images/peeragarhi-mobile.jpg");
			
		}
		else{
			
			$("#banner-img2").attr("src","../include/rs-plugin/demos/assets/images/peeragarhi.jpg");
			
		}
	});
	</script>

	<script>
		$('.blog-slider').slick({
	      //dots: true,
	      infinite: true,
	      centerMode: false,
	      arrows: false,
	      pauseOnFocus: false,
	      centerPadding: '0%',
	      slidesToShow: 3,
	      speed: 500,
	      autoplay: true,
	      autoplaySpeed: 1500,
	      // responsive: [{

	      //       breakpoint: 992,
	      //       settings: {
	      //         slidesToShow: 1
	      //       }

	      //     }]
	      responsive: [
	        {
	          breakpoint: 1024,
	          settings: {
	            slidesToShow: 3
	          }
	        },
	        {
	          breakpoint: 780,
	          settings: {
	            slidesToShow: 2
	          }
	        },
	        {
	          breakpoint: 600,
	          settings: {
	            slidesToShow: 1
	          }
	        }

	      ]
	    });

	</script>


	<script>

			/*Maps*/

      function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 13,
          center: {lat: 28.7, lng: 77.145},
		  styles: [
    {
        "featureType": "all",
        "elementType": "labels.text.fill",
        "stylers": [
            {
                "saturation": 36
            },
            {
                "color": "#333333"
            },
            {
                "lightness": 40
            }
        ]
    },
    {
        "featureType": "all",
        "elementType": "labels.text.stroke",
        "stylers": [
            {
                "visibility": "on"
            },
            {
                "color": "#ffffff"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "all",
        "elementType": "labels.icon",
        "stylers": [
            {
                "visibility": "off"
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "administrative",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#fefefe"
            },
            {
                "lightness": 17
            },
            {
                "weight": 1.2
            }
        ]
    },
    {
        "featureType": "landscape",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f7f2ed"
            },
            {
                "lightness": 20
            }
        ]
    },
    {
        "featureType": "landscape.natural.landcover",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#000000"
            }
        ]
    },
    {
        "featureType": "poi",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f5f5f5"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "featureType": "poi.park",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#dedede"
            },
            {
                "lightness": 21
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 17
            }
        ]
    },
    {
        "featureType": "road.highway",
        "elementType": "geometry.stroke",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 29
            },
            {
                "weight": 0.2
            }
        ]
    },
    {
        "featureType": "road.arterial",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 18
            }
        ]
    },
    {
        "featureType": "road.local",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#ffffff"
            },
            {
                "lightness": 16
            }
        ]
    },
    {
        "featureType": "transit",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#f2f2f2"
            },
            {
                "lightness": 19
            }
        ]
    },
    {
        "featureType": "water",
        "elementType": "geometry",
        "stylers": [
            {
                "color": "#cbf2f2"
            }
        ]
    }
]
        });

        setMarkers(map);
      }

      
      var rpb = [
        ['Wazirpur', 28.704734,77.172242, 4],
		['Rohini Sec-3', 28.703657,77.108054, 3],
		['Peeragarhi', 28.708136,77.124667, 2],
		['Rohini Sec-10', 28.706755,77.105493, 1]
      ];

      function setMarkers(map) {
       
        for (var i = 0; i < rpb.length; i++) {
          var myunits = rpb[i];
          var marker = new google.maps.Marker({
            position: {lat: myunits[1], lng: myunits[2]},
            map: map,
         	icon: '../images/11.png',
			html:	myunits[0],	
            title: myunits[0],
            zIndex: myunits[3]
          });
        }
      }
    </script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAJX5xXhBvqGPED4CMcoTGmGCTcqX99JH4&callback=initMap">
    </script>
   
</body>
</html>